# MiniDesk usage

MiniDesk tek kullanıcılı yerel iş talebi uygulamasıdır. Talepler oluşturulur/düzenlenir, durumları değiştirilir; geçmiş, birlikte çalışan arama/filtreler, özet sayaçları ve UTF-8 JSON dışa aktarma bulunur.

Bu klasörü tek başına kısa bir konuma kopyalayın. Windows x64 ve Python 3.11 ile doğrulanmıştır. Kaynak Python 3.11+ hedefler; paketlenmiş MarkupSafe wheel'i CPython 3.11/Windows x64 içindir. Başka Python/işletim sistemi için uygun wheel gerekir. PowerShell'i bu klasörde açın:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --no-index --find-links wheels --require-hashes --only-binary=:all: -r requirements.bootstrap.txt
.\.venv\Scripts\python.exe -m pip install --no-index --find-links wheels --require-hashes --only-binary=:all: -r requirements.lock.txt
.\.venv\Scripts\python.exe app.py
```

İnternet veya AI Engineer kurulumu gerekmez. Tarayıcıda http://127.0.0.1:8000 adresini açın. İlk açılış boştur. Bir talep oluşturup düzenleyin; todo → doing → done geçişlerini ve done → doing yeniden açmayı kullanın. Todo → done geçişi reddedilir. Talebi seçerek geçmişini görün, arama/öncelik/durum filtrelerini birleştirin ve JSON olarak dışa aktarın.

Sunucuyu Ctrl+C ile durdurun. Aynı klasörde yeniden başlatıldığında `instance/minidesk.sqlite3` içindeki veriler korunur. Bu dosyayı silmeyin; otomatik yedekleme yoktur. Başka veri dosyası için `MINIDESK_DATABASE` ortam değişkeni kullanılabilir. Ürün gerçek müşteri verisiyle veya dış ağlara açılarak kullanılmak üzere tasarlanmamıştır.

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Testler geçici veritabanlarını kullanır. Uygulama/testlerin experiment veya verification klasörlerine ihtiyacı yoktur. Hesap sistemi, çok kullanıcılı çalışma, içe aktarma, silme ve genel ağ yayını kapsam dışıdır.

Özgün README.md kabul edilmiş kaynak dosyasıdır; dondurma öncesi M4 notu ve eski depo düzenine ait deney bağlantıları tarihsel olarak korunur. Güncel ürün kullanım girişi bu dosyadır. Tam teslimattaki kanonik kabul ve kanıtlar experiment/archive altında bulunur; ürün tek başına kopyalandığında bunlar gerekli değildir.
