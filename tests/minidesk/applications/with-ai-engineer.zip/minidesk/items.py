"""Atomic local request writes and their immutable SQL history."""

import json
import sqlite3
from datetime import UTC, date, datetime

import database
from validation import (
    search_key,
    validate_fields,
    validate_filters,
    validate_status,
    validate_transition,
)


class ItemNotFound(LookupError):
    pass


def utc_now() -> str:
    return datetime.now(UTC).isoformat(timespec="microseconds").replace("+00:00", "Z")


def get_item(item_id: int) -> dict[str, object]:
    row = (
        database.get_db()
        .execute("SELECT * FROM items WHERE id = ?", (item_id,))
        .fetchone()
    )
    if row is None:
        raise ItemNotFound("Talep bulunamadı.")
    return dict(row)


def list_items(params: dict[str, str] | None = None) -> list[dict[str, object]]:
    filters = validate_filters(params or {})
    connection = database.get_db()
    connection.create_function("search_key", 1, search_key, deterministic=True)
    arguments = {**filters, "q": search_key(filters["q"])}
    return [
        dict(row)
        for row in connection.execute(
            "SELECT * FROM items WHERE "
            "(:q = '' OR instr(search_key(title), :q) > 0 "
            "OR instr(search_key(description), :q) > 0) "
            "AND (:status = '' OR status = :status) "
            "AND (:priority = '' OR priority = :priority) "
            "ORDER BY updated_at DESC, id DESC",
            arguments,
        ).fetchall()
    ]


def local_today() -> date:
    return date.today()


def summary() -> dict[str, int]:
    row = (
        database.get_db()
        .execute(
            "SELECT count(*) AS total, "
            "coalesce(sum(status != 'done'), 0) AS open, "
            "coalesce(sum(status = 'done'), 0) AS done, "
            "coalesce(sum(status != 'done' AND due_date < ?), 0) AS overdue "
            "FROM items",
            (local_today().isoformat(),),
        )
        .fetchone()
    )
    return dict(row)


def record_event(
    connection: sqlite3.Connection,
    item_id: int,
    event_type: str,
    changes: dict[str, dict[str, object]],
    timestamp: str,
) -> None:
    connection.execute(
        "INSERT INTO events(item_id, event_type, changes, created_at) "
        "VALUES (?, ?, ?, ?)",
        (item_id, event_type, json.dumps(changes, ensure_ascii=False), timestamp),
    )


def create_item(payload: object) -> dict[str, object]:
    fields = validate_fields(payload, creating=True)
    connection = database.get_db()
    timestamp = utc_now()
    with connection:
        cursor = connection.execute(
            "INSERT INTO items(title, description, priority, due_date, created_at, "
            "updated_at) VALUES (?, ?, ?, ?, ?, ?)",
            (
                fields["title"],
                fields["description"],
                fields["priority"],
                fields["due_date"],
                timestamp,
                timestamp,
            ),
        )
        item_id = cursor.lastrowid
        if item_id is None:
            raise sqlite3.DatabaseError("Missing inserted request ID")
        created = get_item(item_id)
        changes = {
            name: {"before": None, "after": value} for name, value in created.items()
        }
        record_event(connection, item_id, "created", changes, timestamp)
    return created


def update_item(item_id: int, payload: object) -> dict[str, object]:
    fields = validate_fields(payload, creating=False)
    connection = database.get_db()
    with connection:
        previous = get_item(item_id)
        changes = {
            name: {"before": previous[name], "after": value}
            for name, value in fields.items()
            if previous[name] != value
        }
        if not changes:
            return previous
        updated = {**previous, **fields}
        timestamp = utc_now()
        connection.execute(
            "UPDATE items SET title = ?, description = ?, priority = ?, "
            "due_date = ?, updated_at = ? WHERE id = ?",
            (
                updated["title"],
                updated["description"],
                updated["priority"],
                updated["due_date"],
                timestamp,
                item_id,
            ),
        )
        record_event(connection, item_id, "updated", changes, timestamp)
        result = get_item(item_id)
    return result


def transition_item(item_id: int, payload: object) -> dict[str, object]:
    target = validate_status(payload)
    connection = database.get_db()
    with connection:
        # Serialize the read/validate/write decision, including its history event.
        connection.execute("BEGIN IMMEDIATE")
        previous = get_item(item_id)
        validate_transition(str(previous["status"]), target)
        timestamp = utc_now()
        connection.execute(
            "UPDATE items SET status = ?, updated_at = ? WHERE id = ?",
            (target, timestamp, item_id),
        )
        record_event(
            connection,
            item_id,
            "status_changed",
            {"status": {"before": previous["status"], "after": target}},
            timestamp,
        )
        result = get_item(item_id)
    return result


def list_events(item_id: int) -> list[dict[str, object]]:
    get_item(item_id)  # Distinguish a nonexistent request from empty history.
    rows = (
        database.get_db()
        .execute(
            "SELECT id, item_id, event_type, created_at, changes FROM events "
            "WHERE item_id = ? ORDER BY id ASC",
            (item_id,),
        )
        .fetchall()
    )
    return [{**dict(row), "changes": json.loads(row["changes"])} for row in rows]
