# MiniDesk

MiniDesk, tek bilgisayarda çalışan yerel iş talebi yönetimi uygulamasıdır. Bu çalışma ağ üzerinden yayınlanan veya çok kullanıcılı bir ürün değildir.

M0–M3'ün bağımsız kabulü tamamlandı. Arama/filtreler, özet sayaçları, gecikme hesabı, JSON dışa aktarma ve durum/geçmiş arayüzü çalışır. Oluşturma, düzenleme ve durum değişikliği geçmiş kayıtları aynı veritabanı işlemi içinde saklanır. **M4 tamamlama doğrulaması ve kendi imzalı bağımsız kabulü ayrıca kaydedilir; henüz M4 nihai kabul PASS ilan edilmez.**

## Windows üzerinde kurulum

Python 3.11 veya daha yeni bir sürüm gerekir. Komutları proje kökünde PowerShell'de çalıştırın:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --require-hashes --only-binary=:all: -r requirements.bootstrap.txt
python -m pip install --require-hashes -r requirements.lock.txt
python app.py
```

Tarayıcıda **http://127.0.0.1:8000/** adresini açın. Varsayılan port 8000; bağlama adresi yalnız `127.0.0.1`. Debugger ve yeniden yükleyici kapalıdır. Sunucuyu Ctrl+C ile durdurabilirsiniz. Başlatıldıktan sonra uygulama internet bağlantısı gerektirmez; ilk bağımlılık kurulumu paket indirmeyi gerektirir.

Aktivasyon PowerShell politikası nedeniyle engellenirse aynı ortamı doğrudan kullanabilirsiniz:

```powershell
.\.venv\Scripts\python.exe -m pip install --require-hashes -r requirements.lock.txt
.\.venv\Scripts\python.exe app.py
```

`requirements.txt` doğrudan Flask sürümünü; `requirements.lock.txt` bu deneyde Windows/Python 3.11 için indirilen bütün uygulama paketlerini, sürümlerini ve wheel hash'lerini sabitler. Farklı platform/yorumlayıcı için yeniden gözden geçirilmiş bir lock gerekebilir; hash denetimini kaldırmayın.

`requirements.bootstrap.txt`, kurulum araçları olan pip ve setuptools'un incelenmiş sürümlerini ve wheel hash'lerini sabitler. Yeni sanal ortamda veya önceki M0 ortamını güncellerken uygulama paketlerinden önce bu dosyayı yükleyin. Aktivasyon kullanmıyorsanız aynı komutu `.\.venv\Scripts\python.exe -m pip` ile çalıştırın. Bu iki araç uygulamanın çalışma zamanı bağımlılığı değildir.

## Yerel veri ve sağlık kontrolü

SQLite dosyası ilk çalıştırmada `instance/minidesk.sqlite3` altında oluşturulur. Yeni veritabanında `items` ve `events` tabloları boş olur. Sonraki başlatmalar mevcut veriyi silmez veya demo içeriği yüklemez. Dosya ve geçici SQLite dosyaları Git dışında tutulur.

`GET /api/health`, iki tabloya erişilebildiğinde HTTP 200 ve `{"status":"ok"}`; veritabanı erişim/şema hatasında HTTP 503 ve JSON hata nesnesi döndürür. Bu yanıt ürünün tüm işlevlerinin kabul edildiği anlamına gelmez. Makine tarafından okunabilir sözleşme [openapi.json](openapi.json) içindedir.

Ayrı bir yerel deneme veritabanı seçmek için:

```powershell
$env:MINIDESK_DATABASE = Join-Path $env:TEMP 'minidesk-local-demo.sqlite3'
python app.py
```

Bu değişkeni gerçek veritabanı yoluna yönlendirmeyin. Sunucuyu durdurduktan sonra aynı PowerShell oturumunda varsayılan yola dönmek için `Remove-Item Env:MINIDESK_DATABASE` kullanabilirsiniz; bu komut veritabanı dosyasını silmez.

## Testler

Aktif sanal ortamda:

```powershell
python -m unittest discover -s tests -v
```

Testler standart `unittest` ve geçici SQLite dosyaları kullanır; varsayılan kullanıcı veritabanına dokunmaz. Test çalışması ağdan paket indirmez. Kanıtlar `governance/user/evidence/development/minidesk/` altında gerçek komut, çıkış kodu ve stdout/stderr ile kaydedilir.

## M1 kullanımı ve API

Başlık, açıklama, öncelik ve isteğe bağlı son tarihi girip **Talebi kaydet** düğmesini kullanın. Listedeki bir talebi seçtiğinizde sunucudaki güncel kayıt forma yüklenir; **Değişiklikleri kaydet** aynı kaydı düzenler. **Yeni talep** formu temizler. Listeyi yenilemek, sunucudaki kayıtları yeniden okur.

Başlık 3–100 karakter, açıklama en fazla 1000 karakterdir. Öncelik `low`, `normal`, `high`; son tarih geçerli `YYYY-MM-DD` veya `null` olur. Yeni talepler `todo` durumundadır. Kimlik, zamanlar ve durum genel düzenlemeyle değiştirilemez. Aynı alan değerlerini tekrar kaydetmek yeni bir geçmiş olayı oluşturmaz.

Yerel sunucu çalışırken PowerShell örneği:

```powershell
$m1Body = @{ title = 'Sentetik teknik talep'; priority = 'normal'; due_date = $null } | ConvertTo-Json
$m1Item = Invoke-RestMethod -Uri 'http://127.0.0.1:8000/api/items' -Method Post -ContentType 'application/json; charset=utf-8' -Body ([System.Text.Encoding]::UTF8.GetBytes($m1Body))
Invoke-RestMethod -Uri 'http://127.0.0.1:8000/api/items'
Invoke-RestMethod -Uri "http://127.0.0.1:8000/api/items/$($m1Item.id)"
```

API yüzeyi: `GET/POST /api/items`, `GET/PATCH /api/items/<id>`. Oluşturma HTTP 201 ve `Location`, liste `{ "items": [...] }`, tekil görüntüleme/düzenleme talep nesnesi döndürür. Bozuk JSON HTTP 400, geçersiz/izin verilmeyen alan HTTP 422, bulunmayan kimlik HTTP 404, veritabanı hatası HTTP 503 olur; hata gövdesi `error.code`, `error.message` ve doğrulamada `error.fields` içerir. Geçersiz veya başarısız yazma kaydı ve geçmişi değiştirmez.

Bağlantı kaydetme sırasında kesilirse sonuç belirsiz olabilir. Arayüz bunu başarı olarak göstermez; yeniden göndermeden önce listeyi yenileyip kaydı kontrol edin. Çoklu yazma çakışması çözümü ve otomatik tekrar deneme yoktur.

## M2 durum geçişleri ve geçmiş API

`POST /api/items/<id>/transition` yalnız `{ "status": "doing" }` biçiminde bir nesne kabul eder. İzinli geçişler `todo -> doing`, `doing -> done`, `done -> doing` şeklindedir. Aynı duruma geçmek dahil diğer geçişler HTTP409 ve `invalid_transition` döndürür; talep, zaman damgası ve geçmiş değişmez. Genel PATCH çağrısında durum alanı hâlâ yasaktır. Geçersiz gövde/alan/durum422, bozuk veya JSON olmayan istek400, olmayan talep404, veritabanı hatası503 olur.

`GET /api/items/<id>/events`, `{ "events": [...] }` içinde oluşum sırasıyla geçmişi döndürür. Her olay `id`, `item_id`, `event_type`, `created_at`, `changes` taşır. `changes`, alan adlarını `{ "before": ..., "after": ... }` değerlerine bağlayan bir nesnedir. Geçmiş değiştirilemez. Başarısız olay yazımı durum değişikliğini de geri alır.

Yerel sunucuda önce oluşturulan sentetik `$m1Item` için:

```powershell
$m2Status = @{ status = 'doing' } | ConvertTo-Json
Invoke-RestMethod -Uri "http://127.0.0.1:8000/api/items/$($m1Item.id)/transition" -Method Post -ContentType 'application/json; charset=utf-8' -Body ([System.Text.Encoding]::UTF8.GetBytes($m2Status))
Invoke-RestMethod -Uri "http://127.0.0.1:8000/api/items/$($m1Item.id)/events"
```

İletişim kesilirse geçişi otomatik tekrar göndermeyin; önce tekil talebi ve geçmişini GET ile kontrol edin. Durum API'si geçiş kararını ve olay yazımını tek işlemde yapar; genel düzenlemenin son yazan kazanır sınırlaması sürer.

## Kapsam ve bilinen sınırlamalar

- M0–M3 kabul edildi; M4 bütünleşik kabul senaryosu, klavye denetimi ve kendi bağımsız kabul zinciri ayrı kanıtlara bağlıdır.
- Kimlik doğrulaması, çok kullanıcı, dış servis, veri silme/içe aktarma ve otomatik yedekleme kapsam dışıdır.
- Yerel Flask sunucusu dış ağlara açılmamalıdır. SQLite dosyasının elle silinmesi veya bozulması veri kaybına yol açabilir.
- İlk kurulum mevcut veriyi korur; şema göçü veya bozuk/uyumsuz veritabanını otomatik onarma yapmaz.
- Initialization'da bildirilen pip/setuptools güvenlik uyarıları tarihsel kayıt olarak korunur. Ürün sanal ortamındaki kurulum araçları `requirements.bootstrap.txt` ile güncellenir; güncel tarama ve önceki ortamın kayıtları ayrı kanıtlardır. Governance araç ortamı otomatik güncellenmez.
- Yol gösterici gereksinim [ROADMAP](governance/user/ROADMAP.md)'tir. Otomatik profildeki hatalı mikroservis/Redis tercihleri kullanılmaz.

## M3 görünürlük ve iş akışı arayüzü

Bir talebi seçip **Başlat**, **Tamamla** veya **Yeniden aç** düğmesini kullanın; yalnız geçerli durum geçişi sunucuda kabul edilir. Seçilen talebin geçmişi oluşturma, düzenleme ve durum değişikliklerinin önceki/yeni değerlerini gösterir. Geçmiş salt okunurdur.

Arama, durum ve öncelik seçimini **Filtrele** ile birlikte uygulayın. **Filtreleri temizle** tüm talepleri yeniden listeler. Arama başlık/açıklama içinde gerçek alt metni arar; `%` ve `_` joker karakter değildir. Unicode casefold kullanılır; Türkçe `I/İ/ı/i` varyantları aramada eşlenir. Kaydedilen metin değişmez. Son güncellenen talep önce gelir; aynı zamanda daha büyük kimlik önce sıralanır.

Özet her zaman **bütün talepleri** kapsar, liste filtrelerinden bağımsızdır. Açık `todo + doing`, tamamlanan `done` kayıtlarıdır. Son tarihi bilgisayarın yerel takvim gününden **önce** olan açık talep gecikmiştir; bugün, boş son tarih veya tamamlanan talep gecikmiş açık sayılmaz. Zaman damgaları UTC kalır. Bilgisayarın tarih/saat ayarı sonuçları etkiler.

**Tüm talepleri JSON indir**, UTF-8 `minidesk-talepler.json` dosyası indirir. Dosya `{ "items": [...] }` biçiminde tüm talepleri kapsar; geçmiş kayıtlarını içermez. Filtreler dışa aktarma kapsamını daraltmaz. İçe aktarma veya silme işlemi yoktur.

Yeni API'ler: `GET /api/items?q=...&status=...&priority=...`, `GET /api/summary`, `GET /api/export`. Filtreler isteğe bağlıdır; boş değer filtresizdir. Tanınan filtrede yanlış enum, tekrar gönderilen parametre veya 1000 karakterden uzun arama422 döndürür; bilinmeyen sorgu parametreleri yok sayılır. Özet `{ "total": 0, "open": 0, "done": 0, "overdue": 0 }` biçimindedir. Export HTTP yanıtı UTF-8 JSON ve attachment başlığı taşır.

Tarayıcı istekleri10 saniyede zaman aşımına uğrar; yazmalar otomatik tekrarlanmaz. Kaydetme veya durum değişikliği yanıtı kaybolursa sonuç belirsizdir. Yeniden göndermeden önce **Listeyi yenile** ile seçilen talebi, geçmişini ve özeti sunucudan tekrar okuyun. Boş liste ile filtre sonucu bulunamaması ayrı gösterilir. Bir görünümün yenilenememesi doğrulanmış yazmayı geri almaz; arayüz bu ayrımı bildirir.

## Baştan sona sentetik kullanım ve kabul örneği

Gerçek veri kullanmadan ayrı bir deneme veritabanıyla yukarıdaki komutları uygulayın. Sunucuyu çalıştırıp yerel sayfayı açtıktan sonra:

1. Başlığı **İş istasyonu inceleme**, önceliği **Yüksek**, son tarihi dün olacak biçimde yeni talep oluşturun. Ayrı bir normal öncelikli talep ve geçmiş tarihli üçüncü talep oluşturun. Sayaçlar bütün listeyi kapsar.
2. İlk talebi listeden seçin, açıklamasını **Sentetik düzenleme** yapıp değişiklikleri kaydedin. Geçmişte created ve updated olaylarını kontrol edin. Formdaki durum salt okunurdur; değişiklik genel düzenlemeyle yapılamaz.
3. İlk talep için **Başlat → Tamamla → Yeniden aç** akışını uygulayın. Üçüncü talebi Başlat ve Tamamla ile kapatın. Toplam3, açık2, tamamlanan1, gecikmiş açık1 beklenir; tamamlanan geçmiş tarihli talep gecikmiş açık sayılmaz.
4. Arama **iş**, durum **Devam ediyor**, öncelik **Yüksek** birlikte uygulandığında ilk talep bulunur. Filtreler özet sayılarını değiştirmez. **Tüm talepleri JSON indir** bütün3 talebi içermeli; olay geçmişini içermemelidir.
5. Yeni talepte boş başlığın kabul edilmediğini görün. API'de boş başlık422, yasak todo→done409 üretir; reddedilen yazılar kayıt/geçmişi değiştirmez. Tarayıcı formu geçersiz girdiyi sunucuya göndermeden engelleyebilir; HTTP kodu otomatik/API testinden değerlendirilir.
6. Sunucuyu Ctrl+C ile durdurup **aynı deneme veritabanı yoluyla** yeniden başlatın. Listeyi yenileyin; kayıtlar, kimlikler, durumlar ve geçmiş korunmalıdır. Farklı veritabanı yolu farklı veri setidir.

Klavye kullanımında Tab/Shift+Tab ile alanlar, seçimler ve düğmeler arasında ilerleyin; native seçimlerde ok tuşlarını, düğmelerde Enter'ı kullanın. Form gönderme, liste kaydı seçme, düzenleme, geçiş, filtreleme ve export kapsamı390px/1280px gerçek renderer denetimine bağlıdır. Bir elemanın script ile focus edilmesi veya axe taraması tek başına doğal Tab sırasını doğrulamaz.

## Kabul kanıtları ve sınırları

M3 nihai kabul [ACCEPTANCE_FINAL.json](governance/user/evidence/development/minidesk/20261014-m3-01a13899/M3/independent-review-inputs/runs/r185629290324p7416/canonical/ACCEPTANCE_FINAL.json) içindedir. Güncel deney anlatımı ve geçmiş başarısızlıklar [EXPERIMENT_REPORT.md](governance/user/evidence/experiments/minidesk-baseline-2.1.1-rc1/20261014-m0-m1-documentation-01a13899/EXPERIMENT_REPORT.md) içinde tutulur. Teknik PASS, bağımsız REVIEW ve final audit ayrı sonuçlardır; M4 yalnız kendi nihai audit PASS kaydıyla kabul edilir.

| ROADMAP başarı ölçütü | Gerçek kanıt kapsamı |
|---|---|
| S-01 | Önceki gerçek M3 create/edit/geçiş/geçmiş browser akışı; M4 yeni bütünleşik API ve kalan doğal klavye denetimi |
| S-02 | Yasak geçiş409 ve boş başlık422 sonrası değişmeyen kayıt/geçmiş; önceki testler ve yeni test_m4 kabul senaryosu |
| S-03 | Birlikte arama/durum/öncelik, global özet ve done kaydın gecikmeden çıkması; M3 testleri/browser ve yeni birleşik senaryo |
| S-04 | Aynı sentetik SQLite ile uygulama/gerçek alt süreç yeniden açılışı; gerçek/default kullanıcı veritabanına dokunulmaz |
| S-05 | Standart unittest komutu; M0–M3'te57 test ve M4'te2 yeni bütünleşik test; gerçek komut sonucu ayrıca kaydedilir |
| S-06 | M3'ün dört genişlikte ölçülen taşmasız düzeni ve axe/Enter; M4'ün390/1280 doğal Tab/Enter akışı ayrıca gerekli |
| S-07 | Kurulum/başlatma/test komutları, bu sentetik örnek, API sözleşmesi ve gerçek kanıtlı deney belgeleri |

Test sayısı tek başına kabul değildir. Otomatik erişilebilirlik/klavye/görsel kontrolleri full WCAG, screen-reader, tüm cihazlar, yüksek yük veya üretim dağıtımı sertifikası değildir. Kimlik doğrulaması yoktur; aynı cihazdaki güvenilmeyen süreçlere karşı koruma sağlandığı iddia edilmez. Son yazan kazanır; otomatik yedekleme/göç/onarma/import/silme yoktur. Yanıtı kaybolan yazmayı otomatik tekrarlamak yerine sunucudaki kayıt ve geçmiş GET ile kontrol edilir.

