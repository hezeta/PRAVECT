"""Whole-product acceptance and reopen invariants using isolated synthetic SQLite."""

import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

from app import create_app


class AcceptanceTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="minidesk-m4-synthetic-")
        self.addCleanup(temporary.cleanup)
        self.config = {
            "TESTING": True,
            "DATABASE": str(Path(temporary.name) / "acceptance.sqlite3"),
        }
        self.client = create_app(self.config).test_client()

    def create(self, title, **fields):
        response = self.client.post("/api/items", json={"title": title, **fields})
        self.assertEqual(response.status_code, 201)
        return response.get_json()

    def stored(self):
        rows = self.client.get("/api/items").get_json()["items"]
        history = {
            row["id"]: self.client.get(f"/api/items/{row['id']}/events").get_json()
            for row in rows
        }
        return rows, history

    def transition(self, item_id, status):
        response = self.client.post(
            f"/api/items/{item_id}/transition", json={"status": status}
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["status"], status)

    def test_s01_s02_s03_s05_whole_product_acceptance(self):
        yesterday = (date.today() - timedelta(days=1)).isoformat()
        first = self.create(
            "İş istasyonu inceleme", priority="high", due_date=yesterday
        )
        self.create("Başka sentetik talep", priority="normal")
        completed = self.create("Tamamlanacak eski talep", due_date=yesterday)
        before = self.stored()
        self.assertEqual(
            self.client.post(
                f"/api/items/{first['id']}/transition", json={"status": "done"}
            ).status_code,
            409,
        )
        self.assertEqual(self.stored(), before)
        self.assertEqual(
            self.client.post("/api/items", json={"title": ""}).status_code, 422
        )
        self.assertEqual(
            self.client.patch(
                f"/api/items/{first['id']}", json={"title": ""}
            ).status_code,
            422,
        )
        self.assertEqual(self.stored(), before)
        updated = self.client.patch(
            f"/api/items/{first['id']}", json={"description": "Sentetik düzenleme 🧪"}
        )
        self.assertEqual(updated.status_code, 200)
        self.assertEqual(updated.get_json()["id"], first["id"])
        self.assertEqual(updated.get_json()["created_at"], first["created_at"])
        for item in [first, completed]:
            self.transition(item["id"], "doing")
            self.transition(item["id"], "done")
        self.assertEqual(
            self.client.get("/api/summary").get_json(),
            {"total": 3, "open": 1, "done": 2, "overdue": 0},
        )
        self.transition(first["id"], "doing")
        filtered = self.client.get(
            "/api/items",
            query_string={"q": "IŞ", "status": "doing", "priority": "high"},
        )
        self.assertEqual(filtered.status_code, 200)
        self.assertEqual(
            [row["id"] for row in filtered.get_json()["items"]], [first["id"]]
        )
        self.assertEqual(
            self.client.get("/api/summary").get_json(),
            {"total": 3, "open": 2, "done": 1, "overdue": 1},
        )
        events = self.client.get(f"/api/items/{first['id']}/events").get_json()[
            "events"
        ]
        self.assertEqual(
            [event["event_type"] for event in events],
            [
                "created",
                "updated",
                "status_changed",
                "status_changed",
                "status_changed",
            ],
        )
        self.assertEqual(
            events[-1]["changes"]["status"], {"before": "done", "after": "doing"}
        )
        export = self.client.get("/api/export?q=absent&status=done")
        self.assertEqual(export.status_code, 200)
        self.assertEqual(
            export.headers["Content-Type"], "application/json; charset=utf-8"
        )
        self.assertIn("attachment", export.headers["Content-Disposition"])
        payload = export.get_json()
        self.assertEqual(set(payload), {"items"})
        self.assertEqual(len(payload["items"]), 3)
        self.assertIn("Sentetik düzenleme 🧪", export.data.decode("utf-8"))
        self.assertEqual(self.client.get("/api/items/999999").status_code, 404)
        self.assertEqual(
            self.client.post(
                "/api/items", data="{", content_type="application/json"
            ).status_code,
            400,
        )

    def test_s04_reopen_preserves_complete_item_and_event_bytes(self):
        first = self.create("Kalıcı sentetik kabul talebi")
        self.transition(first["id"], "doing")
        before = self.stored()
        self.client = create_app(self.config).test_client()
        self.assertEqual(self.client.get("/api/health").status_code, 200)
        self.assertEqual(self.stored(), before)
        self.assertEqual(len(before[1][first["id"]]["events"]), 2)
        isolated = Path(str(self.config["DATABASE"])).with_name("separate.sqlite3")
        other = create_app({"TESTING": True, "DATABASE": str(isolated)}).test_client()
        self.assertEqual(other.get("/api/items").get_json(), {"items": []})
        self.assertEqual(self.stored(), before)


if __name__ == "__main__":
    unittest.main()
