"""M2 workflow invariant, atomic failure, immutable history and persistence tests."""

import itertools
import json
import sqlite3
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Barrier
from unittest.mock import patch

import database
from app import create_app


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="minidesk-m2-synthetic-")
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "test.sqlite3"
        self.config = {"TESTING": True, "DATABASE": str(self.path)}
        self.app = create_app(self.config)
        self.client = self.app.test_client()

    def create(self):
        response = self.client.post("/api/items", json={"title": "Sentetik iş akışı"})
        self.assertEqual(response.status_code, 201)
        return response.get_json()

    def transition(self, item_id, target):
        return self.client.post(
            f"/api/items/{item_id}/transition", json={"status": target}
        )

    def snapshot(self):
        with self.app.app_context():
            return {
                table: [
                    tuple(row)
                    for row in database.get_db().execute(
                        f"SELECT * FROM {table} ORDER BY id"
                    )
                ]
                for table in ["items", "events"]
            }

    def history(self, item_id):
        response = self.client.get(f"/api/items/{item_id}/events")
        self.assertEqual(response.status_code, 200)
        return response.get_json()["events"]

    def test_all_nine_transition_pairs_and_rejected_data_preservation(self):
        allowed = {("todo", "doing"), ("doing", "done"), ("done", "doing")}
        for source, target in itertools.product(["todo", "doing", "done"], repeat=2):
            with self.subTest(source=source, target=target):
                item = self.create()
                if source != "todo":
                    self.assertEqual(
                        self.transition(item["id"], "doing").status_code, 200
                    )
                if source == "done":
                    self.assertEqual(
                        self.transition(item["id"], "done").status_code, 200
                    )
                before = self.snapshot()
                response = self.transition(item["id"], target)
                if (source, target) in allowed:
                    self.assertEqual(response.status_code, 200)
                    self.assertEqual(response.get_json()["status"], target)
                    last = self.history(item["id"])[-1]
                    self.assertEqual(last["event_type"], "status_changed")
                    self.assertEqual(
                        last["changes"], {"status": {"before": source, "after": target}}
                    )
                else:
                    self.assertEqual(response.status_code, 409)
                    self.assertEqual(
                        response.get_json()["error"]["code"], "invalid_transition"
                    )
                    self.assertEqual(self.snapshot(), before)

    def test_invalid_status_body_matrix_preserves_every_table(self):
        item = self.create()
        before = self.snapshot()
        invalid: list[object] = [
            None,
            [],
            "doing",
            1,
            True,
            {},
            {"status": None},
            {"status": []},
            {"status": True},
            {"status": 1},
            {"status": "DOING"},
            {"status": " doing "},
            {"status": "unknown"},
            {"status": "doing", "title": "Forbidden"},
        ]
        for payload in invalid:
            with self.subTest(payload=payload):
                response = self.client.post(
                    f"/api/items/{item['id']}/transition",
                    data=json.dumps(payload),
                    content_type="application/json",
                )
                self.assertEqual(response.status_code, 422)
                self.assertEqual(self.snapshot(), before)

    def test_malformed_and_non_json_transition_are_400(self):
        item = self.create()
        before = self.snapshot()
        for data, content_type in [
            ("{", "application/json"),
            ("doing", "text/plain"),
            ("", "application/json"),
        ]:
            with self.subTest(data=data):
                response = self.client.post(
                    f"/api/items/{item['id']}/transition",
                    data=data,
                    content_type=content_type,
                )
                self.assertEqual(response.status_code, 400)
                self.assertEqual(response.get_json()["error"]["code"], "invalid_json")
                self.assertEqual(self.snapshot(), before)

    def test_missing_item_and_read_only_history_methods(self):
        for response in [
            self.transition(999, "doing"),
            self.client.get("/api/items/999/events"),
        ]:
            self.assertEqual(response.status_code, 404)
        item = self.create()
        before = self.snapshot()
        for method in ["post", "put", "patch", "delete"]:
            self.assertEqual(
                getattr(self.client, method)(
                    f"/api/items/{item['id']}/events", json={}
                ).status_code,
                405,
            )
        self.assertEqual(
            self.client.get(f"/api/items/{item['id']}/transition").status_code, 405
        )
        self.assertEqual(self.snapshot(), before)

    def test_history_structured_scoped_ordered_and_unchanged_by_reads(self):
        item, other = self.create(), self.create()
        self.client.patch(f"/api/items/{item['id']}", json={"description": "Türkçe 🧪"})
        self.transition(item["id"], "doing")
        before = self.snapshot()
        events = self.history(item["id"])
        self.assertEqual(
            [e["event_type"] for e in events], ["created", "updated", "status_changed"]
        )
        self.assertEqual([e["id"] for e in events], sorted(e["id"] for e in events))
        self.assertTrue(all(e["item_id"] == item["id"] for e in events))
        self.assertEqual(
            events[1]["changes"], {"description": {"before": "", "after": "Türkçe 🧪"}}
        )
        self.assertEqual(len(self.history(other["id"])), 1)
        self.assertEqual(self.history(item["id"]), events)
        self.assertEqual(self.snapshot(), before)

    def test_event_failure_rolls_back_status_timestamp_and_history(self):
        item = self.create()
        before = self.snapshot()
        with patch(
            "items.record_event",
            side_effect=sqlite3.OperationalError("Synthetic event failure"),
        ):
            response = self.transition(item["id"], "doing")
        self.assertEqual(response.status_code, 503)
        self.assertEqual(response.get_json()["error"]["code"], "database_unavailable")
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(self.transition(item["id"], "doing").status_code, 200)

    def test_status_transition_preserves_fields_and_uses_one_timestamp(self):
        with patch("items.utc_now", return_value="2026-10-14T10:00:00.000000Z"):
            old = self.create()
        stamp = "2026-10-14T10:00:01.000000Z"
        with patch("items.utc_now", return_value=stamp):
            new = self.transition(old["id"], "doing").get_json()
        for field in [
            "id",
            "title",
            "description",
            "priority",
            "due_date",
            "created_at",
        ]:
            self.assertEqual(new[field], old[field])
        self.assertEqual(new["updated_at"], stamp)
        self.assertEqual(self.history(old["id"])[-1]["created_at"], stamp)

    def test_reopen_retains_done_and_reopen_history(self):
        item = self.create()
        for target in ["doing", "done", "doing"]:
            self.assertEqual(self.transition(item["id"], target).status_code, 200)
        before = self.snapshot()
        expected = self.history(item["id"])
        reopened = create_app(self.config).test_client()
        self.assertEqual(
            reopened.get(f"/api/items/{item['id']}").get_json()["status"], "doing"
        )
        self.assertEqual(
            reopened.get(f"/api/items/{item['id']}/events").get_json()["events"],
            expected,
        )
        self.assertEqual(self.snapshot(), before)

    def test_patch_cannot_bypass_transition_rules(self):
        item = self.create()
        before = self.snapshot()
        self.assertEqual(
            self.client.patch(
                f"/api/items/{item['id']}", json={"status": "done"}
            ).status_code,
            422,
        )
        self.assertEqual(self.snapshot(), before)

    def test_database_checks_and_foreign_keys_after_workflow(self):
        item = self.create()
        for target in ["doing", "done", "doing"]:
            self.transition(item["id"], target)
        with self.app.app_context():
            conn = database.get_db()
            self.assertEqual(conn.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            self.assertEqual(conn.execute("PRAGMA foreign_key_check").fetchall(), [])

    def test_stale_duplicate_transition_does_not_add_history(self):
        item = self.create()
        self.assertEqual(self.transition(item["id"], "doing").status_code, 200)
        before = self.snapshot()
        self.assertEqual(self.transition(item["id"], "doing").status_code, 409)
        self.assertEqual(self.snapshot(), before)

    def test_concurrent_transition_serializes_decision_and_event(self):
        item = self.create()
        barrier = Barrier(2)

        def submit(_):
            client = create_app(self.config).test_client()
            barrier.wait(timeout=10)
            return client.post(
                f"/api/items/{item['id']}/transition", json={"status": "doing"}
            ).status_code

        with ThreadPoolExecutor(max_workers=2) as pool:
            statuses = list(pool.map(submit, range(2)))
        self.assertEqual(sorted(statuses), [200, 409])
        self.assertEqual(len(self.history(item["id"])), 2)


if __name__ == "__main__":
    unittest.main()
