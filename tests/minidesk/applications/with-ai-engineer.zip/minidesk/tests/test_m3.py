"""M3 search/filter, calendar summary, UTF8 export and compatibility tests."""

import itertools
import json
import tempfile
import unittest
from datetime import date
from pathlib import Path
from unittest.mock import patch
from urllib.parse import urlencode

import database
from app import create_app


class VisibilityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="minidesk-m3-synthetic-")
        self.addCleanup(self.temp.cleanup)
        self.config = {
            "TESTING": True,
            "DATABASE": str(Path(self.temp.name) / "test.sqlite3"),
        }
        self.app = create_app(self.config)
        self.client = self.app.test_client()

    def create(self, **fields):
        response = self.client.post(
            "/api/items", json={"title": "Sentetik görünürlük", **fields}
        )
        self.assertEqual(response.status_code, 201)
        return response.get_json()

    def rows(self, **params):
        response = self.client.get("/api/items?" + urlencode(params))
        self.assertEqual(response.status_code, 200)
        return response.get_json()["items"]

    def snapshot(self):
        with self.app.app_context():
            return {
                table: [
                    tuple(row)
                    for row in database.get_db().execute(
                        f"SELECT * FROM {table} ORDER BY id"
                    )
                ]
                for table in ["items", "events"]
            }

    def state(self, item, status):
        if status != "todo":
            self.assertEqual(
                self.client.post(
                    f"/api/items/{item['id']}/transition", json={"status": "doing"}
                ).status_code,
                200,
            )
        if status == "done":
            self.assertEqual(
                self.client.post(
                    f"/api/items/{item['id']}/transition", json={"status": "done"}
                ).status_code,
                200,
            )

    def test_empty_list_summary_and_export(self):
        self.assertEqual(self.rows(), [])
        self.assertEqual(
            self.client.get("/api/summary").get_json(),
            {"total": 0, "open": 0, "done": 0, "overdue": 0},
        )
        self.assertEqual(self.client.get("/api/export").get_json(), {"items": []})

    def test_title_description_unicode_casefold_and_turkish_I(self):
        examples: list[tuple[str, str]] = [
            ("İŞ İstanbul", "iş istanbul"),
            ("ISLAK zemin", "ıslak"),
            ("Straße kontrolü", "STRASSE"),
            ("TürkÇE çalışma", "türkçe"),
        ]
        for title, query in examples:
            with self.subTest(title=title):
                item = self.create(title=title)
                self.assertIn(item["id"], [r["id"] for r in self.rows(q=query)])
        item = self.create(title="Başlık içeriği", description="Açıklama eşleşmesi 🧪")
        self.assertEqual(
            [r["id"] for r in self.rows(q="AÇIKLAMA EŞLEŞMESİ")], [item["id"]]
        )

    def test_literal_percent_underscore_and_sql_looking_input(self):
        item = self.create(title="Yüzde % ve alt _", description="' OR 1=1 --")
        self.create(title="Başka bir talep")
        before = self.snapshot()
        for query in ["%", "_", "' OR 1=1 --"]:
            self.assertEqual([r["id"] for r in self.rows(q=query)], [item["id"]])
        self.assertEqual(self.snapshot(), before)

    def test_combined_filter_cartesian_property_matrix(self):
        records: list[dict[str, object]] = []
        for status, priority in itertools.product(
            ["todo", "doing", "done"], ["low", "normal", "high"]
        ):
            item = self.create(title=f"Ortak {status} {priority}", priority=priority)
            self.state(item, status)
            records.append({**item, "status": status})
        for status, priority, query in itertools.product(
            ["", "todo", "doing", "done"],
            ["", "low", "normal", "high"],
            ["", "ortak", "bulunmayan"],
        ):
            with self.subTest(status=status, priority=priority, query=query):
                expected = {
                    r["id"]
                    for r in records
                    if (not status or r["status"] == status)
                    and (not priority or r["priority"] == priority)
                    and query != "bulunmayan"
                }
                actual = {
                    r["id"]
                    for r in self.rows(q=query, status=status, priority=priority)
                }
                self.assertEqual(actual, expected)

    def test_invalid_and_repeated_filters_422_and_unchanged(self):
        self.create()
        before = self.snapshot()
        for query in [
            "status=unknown",
            "priority=HIGH",
            "status=todo&status=done",
            "priority=low&priority=normal",
            "q=a&q=b",
            "q=" + "x" * 1001,
            "q=" + "+" * 1001,
        ]:
            with self.subTest(query=query[:50]):
                response = self.client.get("/api/items?" + query)
                self.assertEqual(response.status_code, 422)
                self.assertEqual(
                    response.get_json()["error"]["code"], "validation_error"
                )
                self.assertEqual(self.snapshot(), before)

    def test_empty_whitespace_filters_and_unknown_parameter(self):
        item = self.create()
        self.assertEqual(
            self.rows(q="   ", status="", priority="", ignored="anything"), [item]
        )

    def test_global_summary_ignores_filters_and_read_is_pure(self):
        self.create(priority="high")
        self.create(priority="low")
        before = self.snapshot()
        self.assertEqual(len(self.rows(priority="high")), 1)
        self.assertEqual(
            self.client.get("/api/summary?status=done").get_json(),
            {"total": 2, "open": 2, "done": 0, "overdue": 0},
        )
        self.assertEqual(self.snapshot(), before)

    def test_overdue_calendar_boundary_done_null_today_future(self):
        expected_overdue = 0
        for status, due in itertools.product(
            ["todo", "doing", "done"], [None, "2026-10-13", "2026-10-14", "2026-10-15"]
        ):
            item = self.create(due_date=due)
            self.state(item, status)
            if status != "done" and due == "2026-10-13":
                expected_overdue += 1
        with patch("items.local_today", return_value=date(2026, 10, 14)):
            self.assertEqual(
                self.client.get("/api/summary").get_json(),
                {"total": 12, "open": 8, "done": 4, "overdue": expected_overdue},
            )

    def test_summary_refresh_after_complete_and_reopen(self):
        item = self.create(due_date="2026-10-13")
        with patch("items.local_today", return_value=date(2026, 10, 14)):
            self.assertEqual(self.client.get("/api/summary").get_json()["overdue"], 1)
            self.state(item, "done")
            self.assertEqual(
                self.client.get("/api/summary").get_json(),
                {"total": 1, "open": 0, "done": 1, "overdue": 0},
            )
            self.client.post(
                f"/api/items/{item['id']}/transition", json={"status": "doing"}
            )
            self.assertEqual(self.client.get("/api/summary").get_json()["overdue"], 1)

    def test_export_utf8_all_items_no_events_and_attachment(self):
        item = self.create(title="Türkçe dışa aktarım 🧪", priority="high")
        self.create(priority="low")
        self.state(item, "done")
        before = self.snapshot()
        response = self.client.get("/api/export?priority=high")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.headers["Content-Type"], "application/json; charset=utf-8"
        )
        self.assertIn("attachment", response.headers["Content-Disposition"])
        self.assertIn("minidesk-talepler.json", response.headers["Content-Disposition"])
        body = json.loads(response.data.decode("utf-8"))
        self.assertEqual(set(body), {"items"})
        self.assertEqual(len(body["items"]), 2)
        self.assertIn("Türkçe".encode(), response.data)
        self.assertTrue(all(set(r) == set(item) for r in body["items"]))
        self.assertEqual(self.snapshot(), before)

    def test_filtered_order_retains_latest_edit_and_id_tiebreak(self):
        with patch("items.utc_now", return_value="2026-10-14T10:00:00.000000Z"):
            first = self.create()
            second = self.create()
        self.assertEqual(
            [r["id"] for r in self.rows(priority="normal")], [second["id"], first["id"]]
        )
        with patch("items.utc_now", return_value="2026-10-14T10:00:01.000000Z"):
            self.client.patch(
                f"/api/items/{first['id']}", json={"description": "Güncelleme"}
            )
        self.assertEqual(
            [r["id"] for r in self.rows(q="sentetik")], [first["id"], second["id"]]
        )

    def test_reopen_retains_visibility_data_and_history(self):
        item = self.create(title="Kalıcı görünürlük", priority="high")
        self.state(item, "done")
        expected = self.client.get("/api/export").get_json()
        before = self.snapshot()
        reopened = create_app(self.config).test_client()
        self.assertEqual(reopened.get("/api/export").get_json(), expected)
        self.assertEqual(
            reopened.get("/api/items?status=done&priority=high").get_json()["items"],
            expected["items"],
        )
        self.assertEqual(
            len(reopened.get(f"/api/items/{item['id']}/events").get_json()["events"]), 3
        )
        self.assertEqual(self.snapshot(), before)

    def test_visibility_errors_are_json503_without_data_leak(self):
        self.create()
        with self.app.app_context():
            conn = database.get_db()
            conn.execute("DROP TABLE events")
            conn.execute("DROP TABLE items")
            conn.commit()
        for path in ["/api/items?q=search", "/api/summary", "/api/export"]:
            response = self.client.get(path)
            self.assertEqual(response.status_code, 503)
            self.assertEqual(
                response.get_json()["error"]["code"], "database_unavailable"
            )
            self.assertNotIn("SELECT", response.get_json()["error"]["message"])

    def test_summary_and_export_mutations_are_405(self):
        self.create()
        before = self.snapshot()
        for method, path in itertools.product(
            ["post", "put", "patch", "delete"], ["/api/summary", "/api/export"]
        ):
            response = getattr(self.client, method)(path, json={})
            self.assertEqual(response.status_code, 405)
            self.assertIn("error", response.get_json())
        self.assertEqual(self.snapshot(), before)


if __name__ == "__main__":
    unittest.main()
