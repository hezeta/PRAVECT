"""M0 contract, initial schema, persistence and failure-path checks."""

import json
import sqlite3
import tempfile
import unittest
from datetime import UTC, datetime
from html.parser import HTMLParser
from pathlib import Path
from unittest.mock import patch

import database
from app import create_app

ROOT = Path(__file__).resolve().parents[1]


class PageParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tags = []

    def handle_starttag(self, tag, attrs):
        self.tags.append((tag, dict(attrs)))


class SkeletonTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="minidesk-m0-test-")
        self.addCleanup(self.temporary.cleanup)
        self.path = Path(self.temporary.name) / "nested" / "test.sqlite3"
        self.config = {"TESTING": True, "DATABASE": str(self.path)}
        self.app = create_app(self.config)
        self.client = self.app.test_client()

    def insert_item_and_event(self):
        with self.app.app_context():
            connection = database.get_db()
            with connection:
                item_id = connection.execute(
                    "INSERT INTO items(title) VALUES (?)", ("Sentetik talep",)
                ).lastrowid
                connection.execute(
                    "INSERT INTO events(item_id, event_type, changes) VALUES (?, ?, ?)",
                    (
                        item_id,
                        "created",
                        json.dumps(
                            {"title": {"before": None, "after": "Sentetik talep"}}
                        ),
                    ),
                )
            return item_id

    def test_health_matches_machine_readable_contract(self):
        response = self.client.get("/api/health")
        contract = json.loads((ROOT / "openapi.json").read_text(encoding="utf-8"))
        schema = contract["paths"]["/api/health"]["get"]["responses"]["200"]["content"][
            "application/json"
        ]["schema"]
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.mimetype, "application/json")
        body = response.get_json()
        assert isinstance(body, dict)
        self.assertEqual(set(body), set(schema["required"]))
        self.assertEqual(body["status"], schema["properties"]["status"]["const"])

    def test_fresh_database_is_empty_and_has_foreign_key(self):
        self.assertTrue(self.path.is_file())
        with self.app.app_context():
            connection = database.get_db()
            self.assertEqual(
                connection.execute("SELECT count(*) FROM items").fetchone()[0], 0
            )
            self.assertEqual(
                connection.execute("SELECT count(*) FROM events").fetchone()[0], 0
            )
            self.assertEqual(connection.execute("PRAGMA foreign_keys").fetchone()[0], 1)
            keys = connection.execute("PRAGMA foreign_key_list(events)").fetchall()
            self.assertEqual(keys[0]["table"], "items")
            self.assertEqual(keys[0]["on_delete"], "RESTRICT")

    def test_reinitialization_preserves_item_and_history(self):
        item_id = self.insert_item_and_event()
        reopened = create_app(self.config)
        with reopened.app_context():
            connection = database.get_db()
            self.assertEqual(
                connection.execute(
                    "SELECT title FROM items WHERE id=?", (item_id,)
                ).fetchone()[0],
                "Sentetik talep",
            )
            self.assertEqual(
                connection.execute(
                    "SELECT count(*) FROM events WHERE item_id=?", (item_id,)
                ).fetchone()[0],
                1,
            )
        self.assertEqual(reopened.test_client().get("/api/health").status_code, 200)

    def test_orphan_event_is_rejected(self):
        with self.app.app_context():
            with self.assertRaises(sqlite3.IntegrityError):
                with database.get_db() as connection:
                    connection.execute(
                        "INSERT INTO events(item_id,event_type,changes) "
                        "VALUES (999,'created','{}')"
                    )
            self.assertEqual(
                database.get_db().execute("SELECT count(*) FROM events").fetchone()[0],
                0,
            )

    def test_invalid_status_priority_and_title_are_rejected(self):
        with self.app.app_context():
            connection = database.get_db()
            cases = [
                ("Valid title", "invalid", "todo"),
                ("Valid title", "normal", "invalid"),
                (" ", "normal", "todo"),
            ]
            for title, priority, status in cases:
                with self.subTest(title=title, priority=priority, status=status):
                    with self.assertRaises(sqlite3.IntegrityError):
                        with connection:
                            connection.execute(
                                "INSERT INTO items(title,priority,status) "
                                "VALUES (?,?,?)",
                                (title, priority, status),
                            )
            self.assertEqual(
                connection.execute("SELECT count(*) FROM items").fetchone()[0], 0
            )

    def test_history_prevents_parent_deletion(self):
        item_id = self.insert_item_and_event()
        with self.app.app_context():
            connection = database.get_db()
            with self.assertRaises(sqlite3.IntegrityError):
                with connection:
                    connection.execute("DELETE FROM items WHERE id=?", (item_id,))
            self.assertEqual(
                connection.execute("SELECT count(*) FROM items").fetchone()[0], 1
            )
            self.assertEqual(
                connection.execute("SELECT count(*) FROM events").fetchone()[0], 1
            )

    def test_history_requires_valid_json(self):
        item_id = self.insert_item_and_event()
        with self.app.app_context():
            with self.assertRaises(sqlite3.IntegrityError):
                with database.get_db() as connection:
                    connection.execute(
                        "INSERT INTO events(item_id,event_type,changes) "
                        "VALUES (?,'updated',?)",
                        (item_id, "not-json"),
                    )
            self.assertEqual(
                database.get_db().execute("SELECT count(*) FROM events").fetchone()[0],
                1,
            )

    def test_database_defaults_generate_utc_timestamps(self):
        item_id = self.insert_item_and_event()
        with self.app.app_context():
            row = (
                database.get_db()
                .execute("SELECT * FROM items WHERE id=?", (item_id,))
                .fetchone()
            )
            self.assertEqual(row["status"], "todo")
            self.assertEqual(row["priority"], "normal")
            for field in ("created_at", "updated_at"):
                self.assertTrue(row[field].endswith("Z"))
                self.assertEqual(
                    datetime.fromisoformat(row[field].replace("Z", "+00:00")).tzinfo,
                    UTC,
                )

    def test_health_reports_missing_schema(self):
        with self.app.app_context():
            with database.get_db() as connection:
                connection.execute("DROP TABLE events")
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 503)
        body = response.get_json()
        assert isinstance(body, dict)
        self.assertEqual(body["error"]["code"], "database_unavailable")
        self.assertEqual(set(body["error"]), {"code", "message"})
        self.assertIn("erişilemiyor".encode(), response.data)
        self.assertNotIn(str(self.path), response.get_data(as_text=True))

    def test_health_reports_database_exception(self):
        with patch(
            "database.is_ready",
            side_effect=sqlite3.OperationalError("synthetic failure"),
        ):
            with self.assertLogs(self.app.logger, level="WARNING"):
                response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 503)
        body = response.get_json()
        assert isinstance(body, dict)
        self.assertEqual(body["error"]["code"], "database_unavailable")
        self.assertNotIn("synthetic failure", response.get_data(as_text=True))

    def test_temporary_apps_do_not_share_database(self):
        self.insert_item_and_event()
        other = create_app(
            {
                "TESTING": True,
                "DATABASE": str(Path(self.temporary.name) / "other.sqlite3"),
            }
        )
        with other.app_context():
            self.assertEqual(
                database.get_db().execute("SELECT count(*) FROM items").fetchone()[0], 0
            )
        self.assertNotEqual(
            Path(other.config["DATABASE"]), ROOT / "instance" / "minidesk.sqlite3"
        )

    def test_turkish_skeleton_has_semantic_landmarks_and_viewport(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.mimetype, "text/html")
        parser = PageParser()
        parser.feed(response.get_data(as_text=True))
        self.assertIn(("html", {"lang": "tr"}), parser.tags)
        self.assertEqual(sum(tag == "main" for tag, _ in parser.tags), 1)
        self.assertEqual(sum(tag == "h1" for tag, _ in parser.tags), 1)
        self.assertTrue(
            any(
                tag == "meta" and attrs.get("name") == "viewport"
                for tag, attrs in parser.tags
            )
        )
        # M1 replaces the accepted static placeholder with actual task management.
        # The original M0 assertions remain preserved in its immutable archive.
        self.assertTrue(any(tag == "form" for tag, _ in parser.tags))
        self.assertTrue(any(tag == "label" for tag, _ in parser.tags))

    def test_stylesheet_is_served_locally(self):
        response = self.client.get("/static/styles.css")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.mimetype, "text/css")
        response.close()

    def test_health_compatibility_and_implemented_visibility_apis(self):
        self.assertEqual(self.client.post("/api/health").status_code, 405)
        self.assertEqual(self.client.get("/api/items").get_json(), {"items": []})
        summary = self.client.get("/api/summary")
        self.assertEqual(summary.status_code, 200)
        self.assertEqual(
            summary.get_json(), {"total": 0, "open": 0, "done": 0, "overdue": 0}
        )
        export = self.client.get("/api/export")
        self.assertEqual(export.status_code, 200)
        self.assertEqual(export.get_json(), {"items": []})
        self.assertIn("attachment", export.headers["Content-Disposition"])


if __name__ == "__main__":
    unittest.main()
