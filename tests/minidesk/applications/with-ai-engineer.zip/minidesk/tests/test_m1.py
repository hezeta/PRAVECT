"""M1 behavioral, failure-path, boundary and persistence acceptance checks."""

import itertools
import json
import sqlite3
import tempfile
import unittest
from datetime import UTC, datetime
from pathlib import Path
from unittest.mock import patch

import database
from app import create_app


class RequestManagementTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="minidesk-m1-synthetic-")
        self.addCleanup(self.temporary.cleanup)
        self.path = Path(self.temporary.name) / "requests.sqlite3"
        self.config = {"TESTING": True, "DATABASE": str(self.path)}
        self.app = create_app(self.config)
        self.client = self.app.test_client()

    def body(self, response):
        body = response.get_json()
        self.assertIsInstance(body, dict)
        assert isinstance(body, dict)
        return body

    def create(self, **fields):
        response = self.client.post(
            "/api/items", json={"title": "Sentetik talep", **fields}
        )
        self.assertEqual(response.status_code, 201)
        return self.body(response)

    def snapshot(self):
        with self.app.app_context():
            connection = database.get_db()
            return {
                table: [tuple(r) for r in connection.execute(f"SELECT * FROM {table}")]
                for table in ["items", "events"]
            }

    def events(self):
        with self.app.app_context():
            return [
                dict(row) for row in database.get_db().execute("SELECT * FROM events")
            ]

    def test_empty_list_and_default_create(self):
        self.assertEqual(self.body(self.client.get("/api/items")), {"items": []})
        response = self.client.post("/api/items", json={"title": "  İlk talep  "})
        self.assertEqual(response.status_code, 201)
        item = self.body(response)
        self.assertEqual(response.headers["Location"], f"/api/items/{item['id']}")
        self.assertEqual(item["title"], "İlk talep")
        self.assertEqual(item["description"], "")
        self.assertEqual(item["priority"], "normal")
        self.assertEqual(item["status"], "todo")
        self.assertIsNone(item["due_date"])
        self.assertEqual(len(item), 8)
        self.assertEqual(self.body(self.client.get(f"/api/items/{item['id']}")), item)
        self.assertEqual(self.body(self.client.get("/api/items")), {"items": [item]})
        for name in ["created_at", "updated_at"]:
            self.assertTrue(item[name].endswith("Z"))
            self.assertEqual(datetime.fromisoformat(item[name]).tzinfo, UTC)

    def test_all_four_fields_and_unicode_round_trip(self):
        item = self.create(
            title="Türkçe çalışma 🧪",
            description="İş açıklaması\nikinci satır",
            priority="high",
            due_date="2028-02-29",
        )
        self.assertEqual(item["due_date"], "2028-02-29")
        response = self.client.get(f"/api/items/{item['id']}")
        self.assertIn("Türkçe".encode(), response.data)
        self.assertEqual(self.body(response), item)

    def test_created_event_records_before_after_and_timestamp(self):
        item = self.create()
        event = self.events()[0]
        self.assertEqual(event["item_id"], item["id"])
        self.assertEqual(event["event_type"], "created")
        self.assertEqual(event["created_at"], item["created_at"])
        changes = json.loads(event["changes"])
        self.assertEqual(set(changes), set(item))
        for name, value in item.items():
            self.assertEqual(changes[name], {"before": None, "after": value})

    def test_patch_preserves_identity_created_at_and_status(self):
        with patch("items.utc_now", return_value="2026-10-14T10:00:00.000000Z"):
            old = self.create()
        with patch("items.utc_now", return_value="2026-10-14T10:00:01.000000Z"):
            response = self.client.patch(
                f"/api/items/{old['id']}",
                json={
                    "title": "Düzenlenen talep",
                    "description": "Yeni açıklama",
                    "priority": "low",
                    "due_date": "2026-12-31",
                },
            )
        self.assertEqual(response.status_code, 200)
        new = self.body(response)
        for name in ["id", "created_at", "status"]:
            self.assertEqual(new[name], old[name])
        self.assertGreater(new["updated_at"], old["updated_at"])
        event = self.events()[1]
        self.assertEqual(event["event_type"], "updated")
        changes = json.loads(event["changes"])
        self.assertEqual(set(changes), {"title", "description", "priority", "due_date"})
        self.assertEqual(
            changes["title"], {"before": old["title"], "after": new["title"]}
        )

    def test_patch_partial_and_clear_optional_fields(self):
        old = self.create(description="Bir açıklama", due_date="2026-12-31")
        response = self.client.patch(
            f"/api/items/{old['id']}",
            json={
                "description": "",
                "due_date": None,
            },
        )
        self.assertEqual(response.status_code, 200)
        new = self.body(response)
        self.assertEqual(new["description"], "")
        self.assertIsNone(new["due_date"])
        self.assertEqual(new["title"], old["title"])

    def test_noop_patch_does_not_create_event_or_change_timestamp(self):
        old = self.create()
        before = self.snapshot()
        response = self.client.patch(
            f"/api/items/{old['id']}", json={"title": old["title"]}
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.body(response), old)
        self.assertEqual(self.snapshot(), before)

    def test_malformed_and_non_json_are_400(self):
        item = self.create()
        for method, url in [
            ("post", "/api/items"),
            ("patch", f"/api/items/{item['id']}"),
        ]:
            for data, content_type in [
                ("{", "application/json"),
                ("title=value", "text/plain"),
                ("", "application/json"),
            ]:
                with self.subTest(method=method, data=data):
                    before = self.snapshot()
                    response = getattr(self.client, method)(
                        url, data=data, content_type=content_type
                    )
                    self.assertEqual(response.status_code, 400)
                    self.assertEqual(
                        self.body(response)["error"]["code"], "invalid_json"
                    )
                    self.assertEqual(self.snapshot(), before)

    def test_json_non_objects_are_422(self):
        invalid_bodies: list[object] = [None, [], "abc", True, 7]
        for value in invalid_bodies:
            with self.subTest(value=value):
                response = self.client.post(
                    "/api/items",
                    data=json.dumps(value),
                    content_type="application/json",
                )
                self.assertEqual(response.status_code, 422)
                self.assertEqual(self.snapshot(), {"items": [], "events": []})

    def test_invalid_field_property_matrix_preserves_all_data(self):
        item = self.create()
        invalid: dict[str, list[object]] = {
            "title": ["", " ", "ab", "x" * 101, 3, None, [], True],
            "description": ["x" * 1001, None, {}, 8, False],
            "priority": ["urgent", "", None, [], 1, True],
            "due_date": [
                "2026-02-29",
                "2026-13-01",
                "20260101",
                "2026-W01-1",
                "",
                "2026-1-1",
                1,
                False,
                [],
            ],
        }
        for name, values in invalid.items():
            for value, method in itertools.product(values, ["post", "patch"]):
                with self.subTest(field=name, value=value, method=method):
                    before = self.snapshot()
                    payload = {"title": "Valid title", name: value}
                    url = (
                        "/api/items" if method == "post" else f"/api/items/{item['id']}"
                    )
                    response = getattr(self.client, method)(url, json=payload)
                    self.assertEqual(response.status_code, 422)
                    error = self.body(response)["error"]
                    self.assertIn(name, error["fields"])
                    self.assertEqual(self.snapshot(), before)

    def test_valid_boundary_property_matrix(self):
        for length, priority, due in itertools.product(
            [3, 100], ["low", "normal", "high"], [None, "2028-02-29"]
        ):
            with self.subTest(length=length, priority=priority, due=due):
                item = self.create(
                    title="ğ" * length,
                    description="ş" * 1000,
                    priority=priority,
                    due_date=due,
                )
                self.assertEqual(len(item["title"]), length)
                self.assertEqual(len(item["description"]), 1000)
                self.assertEqual(item["priority"], priority)
                self.assertEqual(item["due_date"], due)

    def test_forbidden_fields_and_empty_patch_are_422_and_unchanged(self):
        item = self.create()
        for name in ["id", "status", "created_at", "updated_at", "unknown"]:
            for method in ["post", "patch"]:
                with self.subTest(name=name, method=method):
                    before = self.snapshot()
                    url = (
                        "/api/items" if method == "post" else f"/api/items/{item['id']}"
                    )
                    response = getattr(self.client, method)(
                        url, json={"title": "Title", name: "done"}
                    )
                    self.assertEqual(response.status_code, 422)
                    self.assertEqual(self.snapshot(), before)
        self.assertEqual(
            self.client.patch(f"/api/items/{item['id']}", json={}).status_code, 422
        )

    def test_missing_ids_methods_and_future_routes(self):
        before = self.snapshot()
        for method, url, payload, status in [
            ("get", "/api/items/999", None, 404),
            ("patch", "/api/items/999", {"title": "Updated"}, 404),
            ("get", "/api/items/not-a-number", None, 404),
            ("delete", "/api/items/1", None, 405),
            ("post", "/api/items/999/transition", {"status": "doing"}, 404),
            ("get", "/api/items/999/events", None, 404),
        ]:
            response = getattr(self.client, method)(url, json=payload)
            self.assertEqual(response.status_code, status)
            self.assertIn("error", self.body(response))
        self.assertEqual(self.snapshot(), before)

    def test_create_event_failure_rolls_back_insert(self):
        before = self.snapshot()
        with patch(
            "items.record_event",
            side_effect=sqlite3.OperationalError("synthetic event failure"),
        ):
            with self.assertLogs(self.app.logger, level="WARNING"):
                response = self.client.post(
                    "/api/items", json={"title": "Sentetik talep"}
                )
        self.assertEqual(response.status_code, 503)
        self.assertNotIn("synthetic", response.get_data(as_text=True))
        self.assertEqual(self.snapshot(), before)

    def test_update_event_failure_rolls_back_parent_and_timestamp(self):
        item = self.create()
        before = self.snapshot()
        with patch(
            "items.record_event",
            side_effect=sqlite3.OperationalError("synthetic event failure"),
        ):
            with self.assertLogs(self.app.logger, level="WARNING"):
                response = self.client.patch(
                    f"/api/items/{item['id']}", json={"title": "Changed title"}
                )
        self.assertEqual(response.status_code, 503)
        self.assertEqual(self.snapshot(), before)

    def test_reopen_preserves_api_data_and_history(self):
        item = self.create(
            description="Kalıcı açıklama", priority="high", due_date="2026-12-31"
        )
        updated = self.body(
            self.client.patch(
                f"/api/items/{item['id']}", json={"title": "Kalıcı düzenleme"}
            )
        )
        before = self.snapshot()
        reopened = create_app(self.config)
        self.assertEqual(
            self.body(reopened.test_client().get(f"/api/items/{item['id']}")), updated
        )
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(len(self.events()), 2)

    def test_list_orders_latest_edit_first_with_id_tiebreak(self):
        with patch("items.utc_now", return_value="2026-10-14T10:00:00.000000Z"):
            first = self.create(title="İlk sentetik talep")
            second = self.create(title="İkinci sentetik talep")
        self.assertEqual(
            [item["id"] for item in self.body(self.client.get("/api/items"))["items"]],
            [second["id"], first["id"]],
        )
        with patch("items.utc_now", return_value="2026-10-14T10:00:01.000000Z"):
            self.client.patch(
                f"/api/items/{first['id']}", json={"title": "Güncellenen ilk talep"}
            )
        self.assertEqual(
            self.body(self.client.get("/api/items"))["items"][0]["id"], first["id"]
        )

    def test_sql_looking_content_is_bound_data_and_integrity_holds(self):
        title = "'); DROP TABLE items; --"
        item = self.create(title=title, description="<img src=x onerror=alert(1)>")
        self.assertEqual(
            self.body(self.client.get(f"/api/items/{item['id']}"))["title"], title
        )
        with self.app.app_context():
            connection = database.get_db()
            self.assertEqual(
                connection.execute("PRAGMA integrity_check").fetchone()[0], "ok"
            )
            self.assertEqual(
                connection.execute("PRAGMA foreign_key_check").fetchall(), []
            )


if __name__ == "__main__":
    unittest.main()
