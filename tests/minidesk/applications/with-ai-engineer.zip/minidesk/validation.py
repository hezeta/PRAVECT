"""Framework-independent validation for the four writable request fields."""

from datetime import date

WRITABLE_FIELDS = frozenset({"title", "description", "priority", "due_date"})
PRIORITIES = frozenset({"low", "normal", "high"})
STATUSES = frozenset({"todo", "doing", "done"})
TRANSITIONS = frozenset({("todo", "doing"), ("doing", "done"), ("done", "doing")})


class InvalidTransition(ValueError):
    pass


class ValidationError(ValueError):
    def __init__(self, fields: dict[str, str]):
        super().__init__("Talep bilgilerini kontrol edin.")
        self.fields = fields


def validate_fields(payload: object, *, creating: bool) -> dict[str, str | None]:
    if not isinstance(payload, dict):
        raise ValidationError({"body": "JSON gövdesi bir nesne olmalıdır."})
    errors: dict[str, str] = {}
    unknown = set(payload) - WRITABLE_FIELDS
    if unknown:
        errors["body"] = "Yalnız başlık, açıklama, öncelik ve son tarih değişebilir."
    if not creating and not payload:
        errors["body"] = "En az bir düzenlenebilir alan gönderin."
    fields: dict[str, str | None] = {}
    if creating or "title" in payload:
        title = payload.get("title")
        if (
            not isinstance(title, str)
            or len(title) > 100
            or not 3 <= len(title.strip()) <= 100
        ):
            errors["title"] = "Başlık 3–100 karakter olmalıdır."
        else:
            fields["title"] = title.strip()
    if creating or "description" in payload:
        description = payload.get("description", "")
        if not isinstance(description, str) or len(description) > 1000:
            errors["description"] = "Açıklama en fazla 1000 karakter olmalıdır."
        else:
            fields["description"] = description
    if creating or "priority" in payload:
        priority = payload.get("priority", "normal")
        if not isinstance(priority, str) or priority not in PRIORITIES:
            errors["priority"] = "Geçerli bir öncelik seçin."
        else:
            fields["priority"] = priority
    if creating or "due_date" in payload:
        due_date = payload.get("due_date")
        if due_date is None:
            fields["due_date"] = None
        elif isinstance(due_date, str):
            try:
                parsed = date.fromisoformat(due_date)
                valid = parsed.isoformat() == due_date
            except ValueError:
                valid = False
            if valid:
                fields["due_date"] = due_date
            else:
                errors["due_date"] = "Son tarih geçerli YYYY-MM-DD biçiminde olmalıdır."
        else:
            errors["due_date"] = "Son tarih YYYY-MM-DD veya null olmalıdır."
    if errors:
        raise ValidationError(errors)
    return fields


def validate_status(payload: object) -> str:
    if not isinstance(payload, dict) or set(payload) != {"status"}:
        raise ValidationError({"body": "Yalnız status alanını gönderin."})
    status = payload["status"]
    if not isinstance(status, str) or status not in STATUSES:
        raise ValidationError({"status": "Durum todo, doing veya done olmalıdır."})
    return status


def validate_transition(current: str, target: str) -> None:
    if (current, target) not in TRANSITIONS:
        raise InvalidTransition("Bu durum geçişine izin verilmiyor.")


def search_key(value: str) -> str:
    return value.casefold().replace("i\u0307", "i").replace("ı", "i")


def validate_filters(params: dict[str, str]) -> dict[str, str]:
    errors: dict[str, str] = {}
    raw_query = params.get("q", "")
    query = raw_query.strip()
    if len(raw_query) > 1000:
        errors["q"] = "Arama en fazla 1000 karakter olmalıdır."
    status, priority = params.get("status", ""), params.get("priority", "")
    if status and status not in STATUSES:
        errors["status"] = "Geçerli bir durum filtresi seçin."
    if priority and priority not in PRIORITIES:
        errors["priority"] = "Geçerli bir öncelik filtresi seçin."
    if errors:
        raise ValidationError(errors)
    return {"q": query, "status": status, "priority": priority}
