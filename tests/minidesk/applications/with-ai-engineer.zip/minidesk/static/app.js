"use strict";

const byId = (id) => document.getElementById(id);
const form = byId("item-form");
const list = byId("item-list");
const feedback = byId("feedback");
const names = ["title", "description", "priority", "due_date"];
const priorityNames = { low: "Düşük", normal: "Normal", high: "Yüksek" };
const statusNames = { todo: "Yapılacak", doing: "Devam ediyor", done: "Tamamlandı" };
let selectedId = null;
let selectionSequence = 0;
let loadingSequence = 0;
let saving = false;
let summarySequence = 0;
let exporting = false;
const dateFormatter = new Intl.DateTimeFormat("tr-TR", { dateStyle: "short", timeStyle: "short" });
const eventNames = { created: "Oluşturuldu", updated: "Düzenlendi", status_changed: "Durum değişti" };
const fieldNames = { title: "Başlık", description: "Açıklama", priority: "Öncelik", status: "Durum", due_date: "Son tarih", id: "Kimlik", created_at: "Oluşturulma", updated_at: "Güncelleme" };

class ApiError extends Error {
  constructor(message, fields = {}) { super(message); this.fields = fields; }
}

function notify(message, kind = "info") {
  feedback.textContent = message;
  feedback.dataset.kind = kind;
}

function clearErrors() {
  for (const name of names) {
    byId(name).removeAttribute("aria-invalid");
    byId(`${name}-error`).textContent = "";
  }
}

function showErrors(fields) {
  for (const name of names) {
    if (typeof fields[name] === "string") {
      byId(name).setAttribute("aria-invalid", "true");
      byId(`${name}-error`).textContent = fields[name];
    }
  }
  const first = names.find((name) => fields[name]);
  if (first) byId(first).focus();
}

async function request(url, options = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 10000);
  try {
  let response;
  try {
    response = await fetch(url, { ...options, signal: controller.signal, headers: { "Content-Type": "application/json" } });
  } catch {
    throw new Error("Sunucuya erişilemiyor. Bağlantıyı kontrol edip listeyi yenileyin.");
  }
  let body;
  try { body = await response.json(); }
  catch { throw new Error("Sunucunun yanıtı doğrulanamadı. Listeyi yenileyin."); }
  if (!response.ok) {
    const error = body && typeof body.error === "object" ? body.error : {};
    throw new ApiError(error.message || "İstek başarısız oldu.", error.fields || {});
  }
  return body;
  } finally { clearTimeout(timeout); }
}

function fillForm(item) {
  selectedId = item.id;
  for (const name of names) byId(name).value = item[name] ?? "";
  byId("form-heading").textContent = `Talep #${item.id}`;
  byId("selected-info").textContent = `Durum: ${statusNames[item.status] || item.status}. Oluşturulma: ${dateFormatter.format(new Date(item.created_at))}`;
  byId("save-item").textContent = "Değişiklikleri kaydet";
  markSelection();
  byId("workflow").hidden = false;
  const transition = byId("transition-item");
  transition.dataset.target = item.status === "doing" ? "done" : "doing";
  transition.textContent = item.status === "todo" ? "Başlat" : item.status === "doing" ? "Tamamla" : "Yeniden aç";
}

function clearHistory(message = "Geçmişi görmek için bir talep seçin.") {
  byId("event-list").replaceChildren();
  byId("history-state").textContent = message;
  byId("workflow").hidden = true;
}

async function refreshHistory(id, sequence = selectionSequence) {
  byId("history-state").textContent = "Geçmiş yükleniyor…";
  try {
    const body = await request(`/api/items/${id}/events`);
    if (sequence !== selectionSequence || selectedId !== id) return;
    if (!body || !Array.isArray(body.events)) throw new Error("Geçmiş yanıtı doğrulanamadı.");
    const rows = body.events.map((event) => {
      const row = document.createElement("li");
      const heading = document.createElement("p");
      heading.textContent = `${eventNames[event.event_type] || event.event_type} · ${dateFormatter.format(new Date(event.created_at))}`;
      row.append(heading);
      for (const [field, change] of Object.entries(event.changes)) {
        const detail = document.createElement("p");
        const display = (value) => value === null ? "—" : field === "status" ? (statusNames[value] || value) : field === "priority" ? (priorityNames[value] || value) : String(value);
        detail.textContent = `${fieldNames[field] || field}: ${display(change.before)} → ${display(change.after)}`;
        row.append(detail);
      }
      return row;
    });
    byId("event-list").replaceChildren(...rows);
    byId("history-state").textContent = rows.length ? `${rows.length} işlem` : "Geçmiş kaydı yok.";
  } catch (error) {
    if (sequence === selectionSequence && selectedId === id) {
      byId("event-list").replaceChildren();
      byId("history-state").textContent = "Geçmiş yüklenemedi. Listeyi yenileyerek tekrar deneyin.";
      throw error;
    }
  }
}

function markSelection() {
  for (const button of list.querySelectorAll("button")) {
    button.setAttribute("aria-pressed", String(Number(button.dataset.id) === selectedId));
  }
}

function newItem() {
  if (saving) return;
  selectionSequence += 1;
  selectedId = null;
  clearHistory();
  form.reset();
  clearErrors();
  byId("form-heading").textContent = "Yeni talep";
  byId("selected-info").textContent = "Yeni talepler Yapılacak durumunda kaydedilir.";
  byId("save-item").textContent = "Talebi kaydet";
  markSelection();
  notify("Yeni talep bilgilerini girin.");
  byId("title").focus();
}

async function selectItem(id, focus = true) {
  if (saving) return;
  const sequence = ++selectionSequence;
  notify("Talep yükleniyor…");
  clearHistory("Talep geçmişi yükleniyor…");
  try {
    const item = await request(`/api/items/${id}`);
    if (sequence !== selectionSequence || saving) return;
    clearErrors();
    fillForm(item);
    await refreshHistory(item.id, sequence);
    if (sequence !== selectionSequence) return;
    notify("Talep düzenlemeye hazır.");
    if (focus) byId("title").focus();
  } catch (error) {
    if (sequence === selectionSequence) notify(error.message, "error");
  }
}

function renderItems(items) {
  list.replaceChildren();
  for (const item of items) {
    const row = document.createElement("li");
    const button = document.createElement("button");
    button.type = "button";
    button.className = "item-select";
    button.dataset.id = item.id;
    const title = document.createElement("span");
    title.className = "item-title";
    title.textContent = item.title;
    const meta = document.createElement("span");
    meta.className = "item-meta";
    meta.textContent = `${priorityNames[item.priority]} · ${statusNames[item.status]}${item.due_date ? ` · Son tarih: ${item.due_date}` : ""}`;
    button.append(title, meta);
    button.addEventListener("click", () => selectItem(item.id));
    row.append(button);
    list.append(row);
  }
  markSelection();
  const filtered = Boolean(byId("q").value.trim() || byId("status-filter").value || byId("priority-filter").value);
  byId("list-state").textContent = items.length ? `${items.length} talep` : filtered ? "Filtreyle eşleşen talep yok." : "Henüz talep yok. İlk talebinizi oluşturun.";
}

async function refreshItems() {
  const sequence = ++loadingSequence;
  byId("list-state").textContent = "Talepler yükleniyor…";
  list.setAttribute("aria-busy", "true");
  try {
    const params = new URLSearchParams({ q: byId("q").value, status: byId("status-filter").value, priority: byId("priority-filter").value });
    const body = await request(`/api/items?${params}`);
    if (!body || !Array.isArray(body.items)) throw new Error("Talep listesi doğrulanamadı.");
    if (sequence === loadingSequence) renderItems(body.items);
  } catch (error) {
    if (sequence === loadingSequence) byId("list-state").textContent = "Liste yüklenemedi. Listeyi yenile düğmesiyle tekrar deneyin.";
    throw error;
  } finally {
    if (sequence === loadingSequence) list.removeAttribute("aria-busy");
  }
}

async function refreshSummary() {
  const sequence = ++summarySequence;
  byId("summary-state").textContent = "Özet yükleniyor…";
  try {
    const body = await request("/api/summary");
    if (sequence !== summarySequence) return;
    if (!body || !["total", "open", "done", "overdue"].every((key) => Number.isInteger(body[key]) && body[key] >= 0)) throw new Error("Özet yanıtı doğrulanamadı.");
    for (const key of ["total", "open", "done", "overdue"]) byId(`summary-${key}`).textContent = new Intl.NumberFormat("tr-TR").format(body[key]);
    byId("summary-state").textContent = "Bütün talepler; liste filtrelerinden bağımsız.";
  } catch (error) {
    if (sequence === summarySequence) byId("summary-state").textContent = "Özet güncellenemedi; gösterilen sayılar eski olabilir. Listeyi yenileyin.";
    throw error;
  }
}

function refreshOverview() { return Promise.all([refreshItems(), refreshSummary()]); }

function setSaving(value) {
  saving = value;
  for (const control of document.querySelectorAll("button, input, select, textarea")) control.disabled = value;
  byId("export-items").disabled = value || exporting;
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (saving) return;
  clearErrors();
  const payload = Object.fromEntries(names.map((name) => [name, byId(name).value]));
  payload.due_date = payload.due_date || null;
  const url = selectedId === null ? "/api/items" : `/api/items/${selectedId}`;
  const method = selectedId === null ? "POST" : "PATCH";
  selectionSequence += 1;
  setSaving(true);
  notify("Kaydediliyor…");
  let confirmed = false;
  try {
    const item = await request(url, { method, body: JSON.stringify(payload) });
    if (!item || !Number.isInteger(item.id)) throw new Error("Kaydetme yanıtı doğrulanamadı.");
    confirmed = true;
    fillForm(item);
    await Promise.all([refreshOverview(), refreshHistory(item.id)]);
    notify("Talep kaydedildi.", "success");
  } catch (error) {
    if (confirmed) notify("Talep kaydedildi; liste yenilenemedi. Listeyi yenileyin.", "error");
    else if (error instanceof ApiError) { notify(error.message, "error"); showErrors(error.fields); }
    else notify("Kaydetmenin sonucu doğrulanamadı. Tekrar göndermeden önce listeyi yenileyip kaydı kontrol edin.", "error");
  } finally {
    setSaving(false);
    const first = names.find((name) => byId(name).getAttribute("aria-invalid") === "true");
    if (first) byId(first).focus();
  }
});

byId("new-item").addEventListener("click", newItem);
byId("refresh").addEventListener("click", async () => {
  try { await refreshOverview(); if (selectedId !== null) await selectItem(selectedId, false); else notify("Liste yenilendi."); }
  catch (error) { notify(error.message, "error"); }
});
byId("filters").addEventListener("submit", (event) => {
  event.preventDefault();
  refreshItems().then(() => notify("Filtreler uygulandı.")).catch((error) => notify(error.message, "error"));
});
byId("clear-filters").addEventListener("click", () => {
  byId("filters").reset();
  refreshItems().then(() => notify("Filtreler temizlendi.")).catch((error) => notify(error.message, "error"));
});
byId("transition-item").addEventListener("click", async () => {
  if (saving || selectedId === null) return;
  const id = selectedId;
  const target = byId("transition-item").dataset.target;
  selectionSequence += 1;
  setSaving(true);
  notify("Durum değiştiriliyor…");
  let confirmed = false;
  try {
    const item = await request(`/api/items/${id}/transition`, { method: "POST", body: JSON.stringify({ status: target }) });
    if (!item || item.id !== id || item.status !== target) throw new Error("Durum yanıtı doğrulanamadı.");
    confirmed = true;
    fillForm(item);
    await Promise.all([refreshOverview(), refreshHistory(id)]);
    notify("Durum değiştirildi.", "success");
  } catch (error) {
    if (confirmed) notify("Durum değiştirildi; görünüm yenilenemedi. Listeyi yenileyin.", "error");
    else if (error instanceof ApiError) notify(error.message, "error");
    else notify("Durum değişikliğinin sonucu doğrulanamadı. Tekrar göndermeden önce listeyi yenileyip kaydı ve geçmişi kontrol edin.", "error");
  } finally { setSaving(false); }
});
byId("export-items").addEventListener("click", async () => {
  if (exporting || saving) return;
  exporting = true;
  byId("export-items").disabled = true;
  notify("Dışa aktarma hazırlanıyor…");
  try {
    const body = await request("/api/export");
    if (!body || !Array.isArray(body.items)) throw new Error("Dışa aktarma yanıtı doğrulanamadı.");
    const url = URL.createObjectURL(new Blob([JSON.stringify(body, null, 2) + "\n"], { type: "application/json;charset=utf-8" }));
    const anchor = document.createElement("a");
    anchor.href = url; anchor.download = "minidesk-talepler.json";
    document.body.append(anchor); anchor.click(); anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 0);
    notify("JSON indirme başlatıldı.", "success");
  } catch (error) { notify(error.message, "error"); }
  finally { exporting = false; byId("export-items").disabled = saving; }
});
refreshOverview().catch((error) => notify(error.message, "error"));
