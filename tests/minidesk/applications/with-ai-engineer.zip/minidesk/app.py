"""MiniDesk local HTTP entry point and application factory."""

import os
import sqlite3
from pathlib import Path

from flask import Flask, jsonify, render_template, request, url_for
from flask.json.provider import DefaultJSONProvider
from werkzeug.exceptions import BadRequest, HTTPException

import database
import items
from validation import InvalidTransition, ValidationError


def create_app(test_config: dict | None = None) -> Flask:
    app = Flask(__name__)
    app.config.from_mapping(
        DATABASE=os.environ.get(
            "MINIDESK_DATABASE",
            str(Path(__file__).resolve().parent / "instance" / "minidesk.sqlite3"),
        ),
    )
    if test_config is not None:
        app.config.update(test_config)
    json_provider = DefaultJSONProvider(app)
    json_provider.ensure_ascii = False
    app.json = json_provider
    database.init_app(app)

    def json_body() -> object:
        if not request.is_json:
            raise BadRequest("JSON gövdesi gerekir.")
        return request.get_json()

    @app.errorhandler(ValidationError)
    def invalid_fields(error: ValidationError):
        return jsonify(
            error={
                "code": "validation_error",
                "message": str(error),
                "fields": error.fields,
            }
        ), 422

    @app.errorhandler(items.ItemNotFound)
    def missing_item(error: items.ItemNotFound):
        return jsonify(error={"code": "not_found", "message": str(error)}), 404

    @app.errorhandler(InvalidTransition)
    def invalid_transition(error: InvalidTransition):
        return jsonify(error={"code": "invalid_transition", "message": str(error)}), 409

    @app.errorhandler(HTTPException)
    def http_error(error: HTTPException):
        if not request.path.startswith("/api/"):
            return error
        code = "http_error"
        message = "İstek işlenemedi."
        if error.code == 400:
            code, message = "invalid_json", "Geçerli bir JSON gövdesi gönderin."
        elif error.code == 404:
            code, message = "not_found", "İstenen kaynak bulunamadı."
        elif error.code == 405:
            code, message = "method_not_allowed", "Bu işlem bu adreste desteklenmiyor."
        return jsonify(error={"code": code, "message": message}), error.code or 500

    @app.errorhandler(sqlite3.Error)
    def database_error(_error: sqlite3.Error):
        app.logger.warning("MiniDesk database operation failed.", exc_info=True)
        return jsonify(
            error={
                "code": "database_unavailable",
                "message": "Veritabanına erişilemiyor.",
            }
        ), 503

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/api/health")
    def health():
        try:
            ready = database.is_ready()
        except sqlite3.Error:
            app.logger.warning("MiniDesk database health check failed.", exc_info=True)
            ready = False
        if not ready:
            return jsonify(
                error={
                    "code": "database_unavailable",
                    "message": "Veritabanına erişilemiyor.",
                }
            ), 503
        return jsonify(status="ok")

    @app.get("/api/items")
    def item_list():
        params = {}
        for name in ["q", "status", "priority"]:
            if len(request.args.getlist(name)) > 1:
                raise ValidationError({name: "Filtreyi yalnız bir kez gönderin."})
            params[name] = request.args.get(name, "")
        return jsonify(items=items.list_items(params))

    @app.get("/api/summary")
    def item_summary():
        return jsonify(items.summary())

    @app.get("/api/export")
    def item_export():
        response = jsonify(items=items.list_items())
        response.headers["Content-Disposition"] = (
            'attachment; filename="minidesk-talepler.json"'
        )
        response.headers["Content-Type"] = "application/json; charset=utf-8"
        return response

    @app.post("/api/items")
    def item_create():
        created = items.create_item(json_body())
        response = jsonify(created)
        response.status_code = 201
        response.headers["Location"] = url_for("item_get", item_id=created["id"])
        return response

    @app.get("/api/items/<int:item_id>")
    def item_get(item_id: int):
        return jsonify(items.get_item(item_id))

    @app.patch("/api/items/<int:item_id>")
    def item_update(item_id: int):
        return jsonify(items.update_item(item_id, json_body()))

    @app.post("/api/items/<int:item_id>/transition")
    def item_transition(item_id: int):
        return jsonify(items.transition_item(item_id, json_body()))

    @app.get("/api/items/<int:item_id>/events")
    def item_events(item_id: int):
        return jsonify(events=items.list_events(item_id))

    return app


def main() -> None:
    create_app().run(host="127.0.0.1", port=8000, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
