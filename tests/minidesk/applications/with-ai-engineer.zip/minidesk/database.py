"""SQLite initialization and request-scoped connection ownership."""

import sqlite3
from pathlib import Path

from flask import Flask, current_app, g

SCHEMA = Path(__file__).with_name("schema.sql")


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        connection = sqlite3.connect(current_app.config["DATABASE"])
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        g.db = connection
    return g.db


def close_db(_error: BaseException | None = None) -> None:
    connection = g.pop("db", None)
    if connection is not None:
        connection.close()


def initialize() -> None:
    target = Path(current_app.config["DATABASE"])
    target.parent.mkdir(parents=True, exist_ok=True)
    connection = get_db()
    with connection:
        connection.executescript(
            "BEGIN;\n" + SCHEMA.read_text(encoding="utf-8") + "\nCOMMIT;"
        )


def is_ready() -> bool:
    connection = get_db()
    tables = connection.execute(
        "SELECT name FROM sqlite_master WHERE type = 'table' "
        "AND name IN ('items', 'events')"
    ).fetchall()
    return {row["name"] for row in tables} == {"items", "events"}


def init_app(app: Flask) -> None:
    app.teardown_appcontext(close_db)
    with app.app_context():
        initialize()
