# MiniDesk — Yerel İş Talebi Yönetimi

MiniDesk tek operatörün teknik iş taleplerini kendi bilgisayarında yönetmesini sağlayan, internet ve hesap gerektirmeyen bir web uygulamasıdır. Talep oluşturma/düzenleme, durum makinesi, değişiklik geçmişi, filtreleme, özet sayaçları ve JSON dışa aktarma içerir. Veriler SQLite dosyasında kalır.

> **Teknik tercih farkı:** ROADMAP.md içinde Flask 3.x *tercih edilir*, zorunlu tutulmaz. Bu sürüm Flask yerine Python 3.11+ standart kütüphanesindeki `http.server` ile geliştirilmiştir. Böylece ek paket olmadan kurulabilir ve ağ bağlantısı olmadan gerçek HTTP testleri çalışır. HTTP sunucusu **yalnızca `127.0.0.1:8000`** adresine bağlanır; internete açılmaz. Flask kullanıldığı iddia edilmez. Veri katmanı yine standart `sqlite3`'tür.

## Windows kurulumu

Python 3.11 veya yeni bir sürüm kurulu olmalıdır. ZIP'i açıp PowerShell ile proje klasörüne girin:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```

`requirements.txt` ek bağımlılık içermez; `pip` kullanmadan da `python app.py` çalışır. PowerShell etkinleştirme ilkesi sanal ortamın açılmasına izin vermiyorsa doğrudan `.\.venv\Scripts\python.exe app.py` kullanılabilir.

Tarayıcı adresi: **http://127.0.0.1:8000**

Sunucuyu **Ctrl+C** ile durdurabilirsiniz. İlk açılışta uygulama boş başlar; örnek müşteri verisi yüklenmez. Kaydedilen işler, proje altındaki `data/minidesk.sqlite3` dosyasında kalır. Bu dizin ZIP'e konmaz ve `.gitignore` ile hariç tutulur. Veritabanı yolunu değiştirmek için sunucuyu açmadan önce `MINIDESK_DB` ortam değişkeni tanımlanabilir.

Linux/macOS: `python3 -m venv .venv`, `source .venv/bin/activate`, ardından `python3 app.py`. Python sürümü 3.11+ olmalıdır.

## Arayüzde kullanım

1. **Yeni talep** formunda başlık (3–100 karakter), açıklama (en çok 1000 karakter), öncelik ve isteğe bağlı son tarihi doldurup **Talep oluştur** düğmesini kullanın.
2. Sol listedeki talep başlığına tıklayın veya klavyeyle odaklayıp Enter'a basın. Seçili kaydı sağdaki formdan değiştirebilirsiniz. Kimlik, oluşturulma zamanı ve durum burada değiştirilemez.
3. **Durum ve geçmiş** bölümünde `Bekliyor → Devam ediyor → Tamamlandı` akışını izleyin. Tamamlanan kayıt yalnızca `Devam ediyor` durumuna yeniden açılabilir.
4. Başlık/açıklama içinde arama, durum ve öncelik filtreleri birlikte çalışır. Üstteki sayaçlar bütün kayıtları gösterir; filtrelere göre değişmez. **JSON dışa aktar** yalnızca talep kayıtlarını UTF-8 olarak verir, olay geçmişini içermez.

Talepler sayfa yenilemeyle veya programı kapatıp açmakla kaybolmaz. Tarihi bugünden **önce** olan ve tamamlanmamış kayıtlar gecikmiş sayılır; bunun için çalışılan bilgisayarın yerel takvim günü kullanılır. Zaman damgaları UTC ISO-8601 `Z` biçimindedir.

## Yerel HTTP API

Başarılı yanıtlar `application/json` içerir; liste `{"items": [...], "count": n}`, geçmiş `{"events": [...]}` biçimindedir. Hatalar `{"error": {"code": "...", "message": "..."}}` biçimindedir.

| Yöntem ve yol | İşlev |
| --- | --- |
| `GET /api/health` | Sunucu sağlığı |
| `GET /api/items?q=&status=&priority=` | Aranabilen, filtrelenebilen ve güncellenme zamanına göre sıralanan liste |
| `POST /api/items` | Yeni talep; sonuç HTTP 201 |
| `GET /api/items/1` | Tek talep |
| `PATCH /api/items/1` | Yalnızca başlık, açıklama, öncelik veya son tarihi değiştir |
| `POST /api/items/1/transition` | Geçerli durum geçişi |
| `GET /api/items/1/events` | Talebe bağlı salt okunur olay geçmişi (yeniden eskiye) |
| `GET /api/summary` | `total`, `open`, `done`, `overdue` sayaçları |
| `GET /api/export` | UTF-8 JSON talep dizisi (indirilebilir dosya) |

PowerShell örneği:

```powershell
$body = @{title='Yazıcı bağlantısını denetle'; priority='high'; due_date='2027-01-15'} | ConvertTo-Json
Invoke-RestMethod -Uri http://127.0.0.1:8000/api/items -Method Post -Body $body -ContentType 'application/json; charset=utf-8'
```

Geçiş örneği:

```powershell
Invoke-RestMethod -Uri http://127.0.0.1:8000/api/items/1/transition -Method Post -Body '{"status":"doing"}' -ContentType 'application/json'
```

Yalnızca `todo → doing`, `doing → done`, `done → doing` geçişlerine izin verilir. Yasak geçiş **409**; doğrulama hatası **422**; bozuk JSON **400**; bulunamayan kaynak **404** döner. Uygun olmayan içerik türü 415 ve bilinmeyen HTTP yöntemi 405 döner. Sunucu, veritabanının bütünlüğünü korumak için talep kaydını ve ilgili olayı **tek SQLite işlemiyle** kaydeder.

Olay kaydı biçimi: `{"id":1,"item_id":1,"type":"updated","timestamp":"2026-10-13T10:00:00.000000Z","changes":{"priority":{"before":"normal","after":"high"}}}`. Aynı değerin tekrar gönderilmesi gerçek değişiklik oluşturmadığından ek olay kaydı üretmez.

## Otomatik test

Proje ana dizininde, **internetsiz** ve üretim veritabanına dokunmadan:

```powershell
python -m unittest discover -s tests -v
```

Testler ayrı geçici dizinlerde SQLite oluşturur, gerçek `127.0.0.1` HTTP istekleri yapar, sonra sunucuyu ve test verilerini kapatır. API, veri doğrulama ve ön yüzün temel yapısal denetimlerini kapsar. Gerçek tarayıcıda yalnızca klavye kullanımı ve görünümün insan tarafından değerlendirilmesi de önerilir. Bu paketle yapılan kontrollerin gerçek sonuçları `QA_REPORT.md` dosyasındadır.

## Bilinen sınırlamalar

- **Tek kullanıcı/yerel prototip:** Kimlik doğrulama veya ağdan ortak kullanım yoktur; sunucu başka ağ arabirimlerinde dinlemez. Yerel işletim sistemindeki diğer süreçlerin bağlanması engellenmez.
- **Eşzamanlı düzenleme:** İki ayrı yazma isteğinde son tamamlanan değer geçerlidir; kayıt sürümü veya çakışma arayüzü yoktur.
- **Yedekleme:** SQLite dosyası silinir veya bozulursa otomatik geri yükleme bulunmaz. İçe aktarma ve silme işlevleri de kapsam dışıdır.
- **Arama:** Küçük yerel koleksiyon için durum/öncelik önce SQLite ile süzülür, Unicode metin araması uygulamada yapılır. Çok büyük veri hacimleri hedeflenmez.
- **Tarayıcı:** Yerel JavaScript ve CSS kullanılır; derleme/çatı/bileşen hizmeti gerekmez. Windows tarayıcılarının tamamında bağımsız görsel test koşulmamıştır.

`ROADMAP.md`, orijinal hedef tanımını içerir; bu dosya uygulamanın gerçekleştiğini kanıtlayan belge değildir. Doğrulanmış kapsam için `QA_REPORT.md` ve testler esas alınmalıdır.
