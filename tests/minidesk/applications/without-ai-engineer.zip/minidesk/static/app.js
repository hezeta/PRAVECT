'use strict';

const $ = (id) => document.getElementById(id);
const names = {
  status: {todo: 'Bekliyor', doing: 'Devam ediyor', done: 'Tamamlandı'},
  priority: {low: 'Düşük', normal: 'Normal', high: 'Yüksek'},
  event: {created: 'Talep oluşturuldu', updated: 'Talep düzenlendi', status_changed: 'Durum değiştirildi'},
  field: {title: 'Başlık', description: 'Açıklama', priority: 'Öncelik', status: 'Durum', due_date: 'Son tarih'}
};
const nextStatus = {todo: 'doing', doing: 'done', done: 'doing'};
const nextAction = {todo: 'Çalışmaya başla →', doing: 'Tamamlandı olarak işaretle ✓', done: 'Yeniden aç ↺'};
let selected = null;
let items = [];
let loadSerial = 0;
let historySerial = 0;
let busy = false;
let searchTimer = null;

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, {cache: 'no-store', ...options});
  } catch (_) {
    throw new Error('Sunucuya erişilemiyor. MiniDesk çalışıyor mu? İşlem sonucunu kontrol edin.');
  }
  let data;
  try { data = await response.json(); }
  catch (_) { throw new Error('Sunucudan beklenmeyen bir yanıt alındı.'); }
  if (!response.ok) throw new Error(data?.error?.message || `İstek başarısız (${response.status}).`);
  return data;
}
const jsonRequest = (method, value) => ({method, headers: {'Content-Type': 'application/json'}, body: JSON.stringify(value)});

function notify(message, error = false) {
  const node = $('notice');
  node.textContent = message;
  node.classList.toggle('error', error);
  node.hidden = !message;
}
function setFormError(message) {
  $('form-error').textContent = message;
  $('form-error').hidden = !message;
}
function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text; // Never parse user-supplied HTML.
  return node;
}
function dateLabel(iso) {
  if (!iso) return 'Tarih yok';
  const date = new Date(iso.length === 10 ? `${iso}T12:00:00` : iso);
  return Number.isNaN(date.getTime()) ? iso : date.toLocaleDateString('tr-TR', {day: 'numeric', month: 'short', year: 'numeric'});
}
function overdue(item) {
  const today = new Date();
  const local = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
  return item.status !== 'done' && Boolean(item.due_date) && item.due_date < local;
}
function statusChip(status) {
  return element('span', `status-chip status-${status}`, names.status[status] || status);
}
function renderList() {
  const list = $('item-list');
  list.replaceChildren();
  $('list-count').textContent = String(items.length);
  const term = $('search').value || $('status-filter').value || $('priority-filter').value;
  $('list-message').hidden = items.length > 0;
  if (!items.length) $('list-message').textContent = term
    ? 'Bu filtrelere uygun talep bulunamadı. Arama veya filtreleri değiştirebilirsiniz.'
    : 'Henüz talep yok. İlk kaydı oluşturmak için “Yeni talep” formunu kullanın.';
  for (const item of items) {
    const li = element('li', 'item-card' + (item.id === selected?.id ? ' selected' : ''));
    const button = element('button', 'item-select');
    button.type = 'button';
    button.setAttribute('aria-pressed', String(item.id === selected?.id));
    button.setAttribute('aria-label', `${item.title}, ${names.status[item.status]}. Ayrıntıları göster ve düzenle`);
    button.append(element('span', 'item-title', item.title));
    if (item.description) button.append(element('span', 'item-description', item.description.length > 125 ? `${item.description.slice(0, 125)}…` : item.description));
    const meta = element('span', 'item-meta');
    meta.append(statusChip(item.status));
    meta.append(element('span', `priority-chip priority-${item.priority}`, `${names.priority[item.priority]} öncelik`));
    if (item.due_date) meta.append(element('span', overdue(item) ? 'item-overdue' : '', `${overdue(item) ? 'Gecikti · ' : ''}${dateLabel(item.due_date)}`));
    button.append(meta);
    button.addEventListener('click', () => choose(item));
    li.append(button);
    list.append(li);
  }
}
function renderSummary(data) {
  for (const key of ['total', 'open', 'done', 'overdue']) $(`${key}-value`).textContent = String(data[key]);
}
async function reload() {
  const serial = ++loadSerial;
  const params = new URLSearchParams();
  const q = $('search').value.trim();
  if (q) params.set('q', q);
  if ($('status-filter').value) params.set('status', $('status-filter').value);
  if ($('priority-filter').value) params.set('priority', $('priority-filter').value);
  const suffix = params.size ? `?${params.toString()}` : '';
  try {
    const [response, stats] = await Promise.all([api(`/api/items${suffix}`), api('/api/summary')]);
    if (serial !== loadSerial) return;
    items = response.items;
    renderList();
    renderSummary(stats);
  } catch (error) {
    if (serial !== loadSerial) return;
    $('list-message').hidden = false;
    $('list-message').textContent = 'Talepler yüklenemedi. Sunucu bağlantısını kontrol edin.';
    $('item-list').replaceChildren();
    notify(error.message, true);
  }
}
function resetForm(focus = true) {
  selected = null;
  ++historySerial;
  $('item-form').reset();
  $('editor-title').textContent = 'Yeni talep oluştur';
  $('editor-mode').textContent = 'YENİ';
  $('submit-button').textContent = 'Talep oluştur';
  $('cancel-edit').hidden = true;
  $('detail').hidden = true;
  $('detail-empty').hidden = false;
  setFormError('');
  renderList();
  if (focus) $('title').focus();
}
function applySelection(item) {
  selected = item;
  $('editor-title').textContent = 'Talebi düzenle';
  $('editor-mode').textContent = `#${item.id}`;
  $('submit-button').textContent = 'Değişiklikleri kaydet';
  $('cancel-edit').hidden = false;
  $('title').value = item.title;
  $('description').value = item.description;
  $('priority').value = item.priority;
  $('due-date').value = item.due_date || '';
  setFormError('');
  $('detail-empty').hidden = true;
  $('detail').hidden = false;
  $('selected-title').textContent = item.title;
  $('selected-status').className = `status-chip status-${item.status}`;
  $('selected-status').textContent = names.status[item.status];
  $('selected-id').textContent = `Talep #${item.id}`;
  $('selected-updated').textContent = `Güncelleme: ${dateLabel(item.updated_at)}`;
  $('transition-button').textContent = nextAction[item.status];
  $('transition-button').disabled = busy;
  renderList();
}
async function refreshHistory(itemId) {
  const serial = ++historySerial;
  $('event-list').replaceChildren();
  $('event-message').hidden = false;
  $('event-message').textContent = 'Geçmiş yükleniyor…';
  try {
    const response = await api(`/api/items/${itemId}/events`);
    if (selected?.id !== itemId || serial !== historySerial) return;
    $('event-message').hidden = true;
    for (const event of response.events) {
      const li = element('li', 'event-entry');
      li.append(element('div', 'event-label', names.event[event.type] || event.type));
      li.append(element('div', 'event-time', dateLabel(event.timestamp)));
      const dl = element('dl', 'event-changes');
      for (const [key, change] of Object.entries(event.changes)) {
        const line = element('div', 'event-change');
        line.append(element('dt', '', `${names.field[key] || key}:`));
        const before = formatValue(key, change.before);
        const after = formatValue(key, change.after);
        line.append(element('dd', '', `${before} → ${after}`));
        dl.append(line);
      }
      li.append(dl);
      $('event-list').append(li);
    }
    if (!response.events.length) {
      $('event-message').textContent = 'Bu talebin henüz işlem geçmişi yok.';
      $('event-message').hidden = false;
    }
  } catch (error) {
    if (selected?.id === itemId && serial === historySerial) {
      $('event-message').textContent = error.message;
      $('event-message').hidden = false;
    }
  }
}
function formatValue(key, value) {
  if (value === null || value === undefined || value === '') return '—';
  if (key === 'status') return names.status[value] || value;
  if (key === 'priority') return names.priority[value] || value;
  if (key === 'due_date') return dateLabel(value);
  return String(value);
}
function choose(item) {
  applySelection(item);
  refreshHistory(item.id);
}
function setBusy(value) {
  busy = value;
  $('submit-button').disabled = value;
  $('transition-button').disabled = value;
  $('cancel-edit').disabled = value;
  $('new-item-top').disabled = value;
}
async function save(event) {
  event.preventDefault();
  if (busy) return;
  setFormError('');
  const payload = {title: $('title').value.trim(), description: $('description').value,
    priority: $('priority').value, due_date: $('due-date').value || null};
  if (payload.title.length < 3 || payload.title.length > 100 || payload.description.trim().length > 1000) {
    setFormError('Başlık 3–100, açıklama en çok 1000 karakter olmalıdır.');
    $('form-error').focus?.();
    return;
  }
  setBusy(true);
  const isEditing = Boolean(selected);
  const id = selected?.id;
  try {
    const item = await api(isEditing ? `/api/items/${id}` : '/api/items', jsonRequest(isEditing ? 'PATCH' : 'POST', payload));
    applySelection(item);
    notify(isEditing ? 'Talep kaydedildi.' : 'Yeni talep oluşturuldu.');
    await Promise.all([reload(), refreshHistory(item.id)]);
  } catch (error) {
    setFormError(error.message);
    notify(error.message, true);
  } finally { setBusy(false); }
}
async function transition() {
  if (!selected || busy) return;
  const previous = selected;
  setBusy(true);
  try {
    const item = await api(`/api/items/${previous.id}/transition`, jsonRequest('POST', {status: nextStatus[previous.status]}));
    applySelection(item);
    notify('Talep durumu güncellendi.');
    await Promise.all([reload(), refreshHistory(item.id)]);
  } catch (error) {
    notify(error.message, true);
  } finally { setBusy(false); }
}
$('new-item-top').addEventListener('click', () => { resetForm(); notify(''); });
$('cancel-edit').addEventListener('click', () => resetForm());
$('item-form').addEventListener('submit', save);
$('transition-button').addEventListener('click', transition);
$('filters').addEventListener('submit', (event) => event.preventDefault());
$('search').addEventListener('input', () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(reload, 220);
});
for (const name of ['status-filter', 'priority-filter']) $(name).addEventListener('change', reload);
reload();
