"""MiniDesk local HTTP server; Python 3.11+ standard library only."""
import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import re
import sqlite3
from urllib.parse import parse_qs, urlsplit

from database import get_events, get_item, initialize, list_items, summary
from service import InvalidTransition, MissingItem, insert_item, transition_item, update_item
from validation import ValidationError, validate_fields, validate_filters, validate_transition

ROOT = Path(__file__).resolve().parent
DEFAULT_DB = ROOT / "data" / "minidesk.sqlite3"
ITEM_ROUTE = re.compile(r"/api/items/([1-9]\d*)\Z")
TRANSITION_ROUTE = re.compile(r"/api/items/([1-9]\d*)/transition\Z")
EVENTS_ROUTE = re.compile(r"/api/items/([1-9]\d*)/events\Z")
STATIC = {
    "/": ("static/index.html", "text/html; charset=utf-8"),
    "/styles.css": ("static/styles.css", "text/css; charset=utf-8"),
    "/app.js": ("static/app.js", "text/javascript; charset=utf-8"),
}


class RequestProblem(Exception):
    def __init__(self, status, code, message):
        self.status, self.code, self.message = status, code, message


class LocalHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def handler_for(db_path):
    class MiniDeskHandler(BaseHTTPRequestHandler):
        server_version = "MiniDesk/1.0"
        sys_version = ""

        def respond(self, status, body, content_type="application/json; charset=utf-8", headers=None):
            payload = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; base-uri 'none'; object-src 'none'; form-action 'self'")
            for name, value in (headers or {}).items():
                self.send_header(name, value)
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(payload)

        def fail(self, status, code, message):
            self.respond(status, {"error": {"code": code, "message": message}})

        def parse_body(self):
            content_type = self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
            if content_type != "application/json":
                raise RequestProblem(415, "unsupported_media_type", "Content-Type application/json olmalıdır.")
            length_text = self.headers.get("Content-Length")
            if length_text is None:
                raise RequestProblem(400, "bad_json", "JSON gövdesi eksik.")
            try:
                length = int(length_text)
            except ValueError as exc:
                raise RequestProblem(400, "bad_json", "Geçersiz gövde uzunluğu.") from exc
            if length <= 0 or length > 131072:
                raise RequestProblem(400, "bad_json", "JSON gövdesi boş veya çok büyük.")
            try:
                return json.loads(self.rfile.read(length).decode("utf-8"))
            except (ValueError, UnicodeDecodeError) as exc:
                raise RequestProblem(400, "bad_json", "Bozuk JSON gövdesi.") from exc

        def dispatch(self):
            parsed = urlsplit(self.path)
            path = parsed.path
            method = self.command
            try:
                if path in STATIC:
                    if method not in ("GET", "HEAD"):
                        raise RequestProblem(405, "method_not_allowed", "Bu yöntem desteklenmiyor.")
                    relative, content_type = STATIC[path]
                    self.respond(200, (ROOT / relative).read_bytes(), content_type)
                    return
                if not path.startswith("/api/"):
                    raise RequestProblem(404, "not_found", "Adres bulunamadı.")

                if path == "/api/health" and method == "GET":
                    self.respond(200, {"status": "ok"})
                elif path == "/api/items" and method == "GET":
                    params = {key: vals[-1] for key, vals in parse_qs(parsed.query, keep_blank_values=True).items()}
                    filters = validate_filters(params)
                    items = list_items(db_path, **filters)
                    self.respond(200, {"items": items, "count": len(items)})
                elif path == "/api/items" and method == "POST":
                    data = validate_fields(self.parse_body(), creating=True)
                    item = insert_item(db_path, data)
                    self.respond(201, item, headers={"Location": f"/api/items/{item['id']}"})
                elif path == "/api/summary" and method == "GET":
                    self.respond(200, summary(db_path))
                elif path == "/api/export" and method == "GET":
                    data = json.dumps(list_items(db_path), ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
                    self.respond(200, data, "application/json; charset=utf-8", {
                        "Content-Disposition": 'attachment; filename="minidesk-items.json"'
                    })
                elif (match := ITEM_ROUTE.fullmatch(path)):
                    item_id = int(match.group(1))
                    if method == "GET":
                        item = get_item(db_path, item_id)
                        if item is None:
                            raise MissingItem
                        self.respond(200, item)
                    elif method == "PATCH":
                        data = validate_fields(self.parse_body())
                        self.respond(200, update_item(db_path, item_id, data))
                    else:
                        raise RequestProblem(405, "method_not_allowed", "Bu yöntem desteklenmiyor.")
                elif (match := TRANSITION_ROUTE.fullmatch(path)):
                    if method != "POST":
                        raise RequestProblem(405, "method_not_allowed", "Bu yöntem desteklenmiyor.")
                    target = validate_transition(self.parse_body())
                    self.respond(200, transition_item(db_path, int(match.group(1)), target))
                elif (match := EVENTS_ROUTE.fullmatch(path)):
                    if method != "GET":
                        raise RequestProblem(405, "method_not_allowed", "Bu yöntem desteklenmiyor.")
                    item_id = int(match.group(1))
                    if get_item(db_path, item_id) is None:
                        raise MissingItem
                    self.respond(200, {"events": get_events(db_path, item_id)})
                else:
                    # Known resource with the wrong method is a method error, not a missing resource.
                    if path in ("/api/health", "/api/summary", "/api/export", "/api/items"):
                        raise RequestProblem(405, "method_not_allowed", "Bu yöntem desteklenmiyor.")
                    raise RequestProblem(404, "not_found", "Adres bulunamadı.")
            except RequestProblem as exc:
                self.fail(exc.status, exc.code, exc.message)
            except ValidationError as exc:
                self.fail(422, "validation_error", str(exc))
            except MissingItem:
                self.fail(404, "not_found", "Talep bulunamadı.")
            except InvalidTransition as exc:
                self.fail(409, "invalid_transition", str(exc))
            except sqlite3.DatabaseError as exc:
                self.log_error("Veritabanı hatası: %s", type(exc).__name__)
                self.fail(500, "storage_error", "Veritabanı işlemi tamamlanamadı.")
            except OSError as exc:
                self.log_error("Dosya erişim hatası: %s", type(exc).__name__)
                self.fail(500, "server_error", "Yerel sunucu hatası.")

        def do_GET(self):
            self.dispatch()

        def do_HEAD(self):
            self.dispatch()

        def do_POST(self):
            self.dispatch()

        def do_PATCH(self):
            self.dispatch()

        def do_PUT(self):
            self.dispatch()

        def do_DELETE(self):
            self.dispatch()

        def do_OPTIONS(self):
            self.dispatch()

    return MiniDeskHandler


def create_server(db_path=None, port=8000):
    """Bind strictly to local loopback. Port 0 can be used by isolated tests."""
    db_path = Path(db_path or os.environ.get("MINIDESK_DB", DEFAULT_DB)).resolve()
    initialize(db_path)
    return LocalHTTPServer(("127.0.0.1", port), handler_for(db_path))


def main():
    server = create_server()
    print(f"MiniDesk çalışıyor: http://127.0.0.1:{server.server_port}")
    print("Durdurmak için Ctrl+C")
    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
