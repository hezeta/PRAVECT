# MiniDesk — Kabul ve Kalite Doğrulaması

**Geliştirme tarih:** 2026-10-13. **Kaynak:** Ekteki `ROADMAP.md`. Kod, önceki eklenti/ajan uygulamasından alınmamıştır.

## Kaydedilmiş kontroller

| Denetim | Sonuç | Açıklama |
| --- | --- | --- |
| Python derlenebilirliği | GEÇTİ | Uygulama ve test kaynakları `compileall` ile kontrol edildi. |
| JavaScript sözdizimi | GEÇTİ | `node --check static/app.js`. Node uygulamanın çalışması için gerekmez. |
| Standart unittest | **38/38 GEÇTİ** | `python -m unittest discover -s tests -v`; ağ olmadan yerel HTTP sunucusu ve geçici SQLite kullanıldı. |
| Yasak `todo → done` | GEÇTİ | HTTP 409, kayıt ve olaylar değişmedi. |
| Boş başlık, bozuk JSON, bulunmayan kayıt | GEÇTİ | Sırasıyla 422, 400, 404. |
| Üç atomiklik arızası | GEÇTİ | Oluşturma, düzenleme ve geçiş esnasında `events` eklemesi SQL tetikleyicisiyle bilerek bozuldu; veri değişikliği geri alındı. |
| Yeniden başlatmada kalıcılık | GEÇTİ | Sunucu yeniden oluşturulduğunda kayıt ve geçmiş korundu. |
| Gerçek Chromium etkileşimi | GEÇTİ* | Oluşturma, düzenleme, üç durum geçişi, geçmiş, filtreler, yeniden sayfa kurulumu, Enter ile kayıt seçimi ve form gönderimi. |
| Mobil/masaüstü yatay taşma | GEÇTİ* | Chromium 144'te 320, 390 ve 1280 piksel genişlik; `scrollWidth == clientWidth`. |
| Arayüz hata durumları | GEÇTİ* | Geçersiz başlık form hatası; bağlantı kesilmesi için başarısız bağlantı bildirimi. |
| Kullanıcı HTML'sinin çalıştırılmaması | GEÇTİ* | Zararlı örnek başlık düz metin olarak görüntülendi; HTML görsele dönüştürülmedi. |
| Tarayıcı JavaScript hataları | GEÇTİ* | Denenen iş akışlarında yakalanmış hata yok. |

**(*) Tarayıcı sınırı:** Bu yürütme ortamının Chromium yönetim ilkesi, `http://127.0.0.1` adresine tarayıcıdan doğrudan gezinmeyi engelliyor. Ön yüz gerçek başsız Chromium'da oluşturuldu, yerel HTTP istekleri test aracı tarafından Python üzerinden çalışan sunucuya aktarıldı. Bu yöntem DOM, JavaScript etkileşimleri ve düzen ölçülerini gerçekten denetledi; ancak normal tarayıcıdan uçtan uca HTTP gezinmesi veya Windows'taki tarayıcı davranışı burada ayrıca doğrulanmadı. Python bütünleştirme testleri gerçek yerel HTTP isteklerini doğrudan kullanmıştır.

## Roadmap kapsam değerlendirmesi

- **M0 — tamamlandı:** Yerel sunucu, ilk SQLite şeması, boş durum, sağlık API'si ve kurulum metni.
- **M1 — tamamlandı:** Sunucu tarafında veri doğrulama, talep oluşturma/listeleme/tekil görüntüleme/düzenleme; değişmez kimlik/oluşturulma tarihi; kalıcılık testleri.
- **M2 — tamamlandı:** İzinli/yasak durum geçişleri, salt okunur olay geçmişi, aynı işlem içindeki atomik yazımlar ve hata testleri.
- **M3 — tamamlandı:** Türkçe arayüz, arama, birlikte çalışan filtreler, özet/gecikme, UTF-8 dışa aktarma, responsive stiller, boş/hata/başarılı durumları.
- **M4 — büyük ölçüde doğrulandı:** Otomatik testler, Chromium'da klavyeyle kayıt seçme ve 320/390/1280 taşma denetimi. Windows üzerinde tam insan erişilebilirlik denetimi bu ortamda yapılmadığından **tam platform kapsamı doğrulanmadı**.

## Yol ayrımı ve kapsam dışı tutulanlar

`O-02` Flask 3.x'i tercih olarak belirtir; çalışma ortamında Flask yüklü olmadığı ve paket deposuna erişilemediği için geliştirilen sürüm HTTP için Python'un `http.server` kütüphanesini kullanır. Bu **Flask uygulaması değildir**. Diğer modüller standart kütüphane, HTML, CSS ve düz JavaScript'tir. Ayrı mimari kurulum veya ücretli servis yoktur.

Kimlik doğrulama, içe aktarma, silme, toplu düzenleme, WebSocket, bildirim, dağıtım, yedekleme ve eşzamanlı düzenleme çözümü roadmap gereği uygulanmamıştır. Ürün yalnızca tek bilgisayarda, yerel kullanım içindir.

## Elle tekrarlanabilir kabul senaryosu

1. `python app.py` ile açın; özet sayaçlarının `0`, listenin boş olduğunu doğrulayın.
2. Başlığı ve önceliği olan iki talep ekleyin. İlkini seçip açıklamayı değiştirin, geçmişte `created` ve `updated` olaylarını gözlemleyin.
3. İlk talebi `todo → doing → done` geçişlerinden geçirin; sonra `done → doing` ile yeniden açın.
4. Filtreleri birlikte etkinleştirip yalnızca doğru sonuçların kaldığını ve özet sayaçlarının tüm kayıtları göstermeyi sürdürdüğünü doğrulayın.
5. Tarihi geçmiş bir açık talep oluşturup gecikme sayısını kontrol edin; tamamlayınca gecikme sayısının azaldığını görün.
6. JSON dışa aktarın; olay verisi içermediğini doğrulayın. Sunucuyu durdurup açın; kayıt ve geçmişin kaldığını görün.
7. Klavyeyle Tab/Enter kullanarak kayıt seçin ve formu gönderin; 390px ve 1280px tarayıcı genişliklerinde yatay taşma bulunmadığını kontrol edin.

Bu metindeki sonuçlar yalnızca çalıştırılan testlerin kanıtladığı sınırlar için geçerlidir. Özellikle Windows üzerinde gerçek kullanım ve farklı tarayıcı uyumluluğu ek kabul testleri gerektirir.
