"""MiniDesk input rules. All mutation input is validated on the server."""
from datetime import date
import re

FIELDS = frozenset({"title", "description", "priority", "due_date"})
PRIORITIES = frozenset({"low", "normal", "high"})
STATUSES = frozenset({"todo", "doing", "done"})
TRANSITIONS = {"todo": "doing", "doing": "done", "done": "doing"}
DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}\Z")


class ValidationError(ValueError):
    pass


def validate_fields(payload, *, creating=False):
    if not isinstance(payload, dict):
        raise ValidationError("İstek bir JSON nesnesi olmalıdır.")
    unknown = set(payload) - FIELDS
    if unknown:
        raise ValidationError("İzin verilmeyen alan: " + ", ".join(sorted(unknown)))
    if not creating and not payload:
        raise ValidationError("En az bir alan gönderilmelidir.")
    if creating and "title" not in payload:
        raise ValidationError("Başlık zorunludur.")

    data = {"description": "", "priority": "normal", "due_date": None} if creating else {}
    for key, value in payload.items():
        if key == "title":
            if not isinstance(value, str):
                raise ValidationError("Başlık metin olmalıdır.")
            value = value.strip()
            if not 3 <= len(value) <= 100:
                raise ValidationError("Başlık 3–100 karakter olmalıdır.")
        elif key == "description":
            if not isinstance(value, str):
                raise ValidationError("Açıklama metin olmalıdır.")
            value = value.strip()
            if len(value) > 1000:
                raise ValidationError("Açıklama en çok 1000 karakter olmalıdır.")
        elif key == "priority":
            if not isinstance(value, str) or value not in PRIORITIES:
                raise ValidationError("Öncelik low, normal veya high olmalıdır.")
        elif key == "due_date":
            if value == "" or value is None:
                value = None
            elif not isinstance(value, str) or not DATE_RE.fullmatch(value):
                raise ValidationError("Son tarih YYYY-MM-DD biçiminde olmalıdır.")
            else:
                try:
                    date.fromisoformat(value)
                except ValueError as exc:
                    raise ValidationError("Son tarih geçerli bir takvim tarihi olmalıdır.") from exc
        data[key] = value
    return data


def validate_transition(payload):
    if not isinstance(payload, dict) or set(payload) != {"status"}:
        raise ValidationError("Yalnızca status alanı gönderilmelidir.")
    status = payload["status"]
    if not isinstance(status, str) or status not in STATUSES:
        raise ValidationError("Durum todo, doing veya done olmalıdır.")
    return status


def validate_filters(params):
    status, priority = params.get("status", ""), params.get("priority", "")
    if status and status not in STATUSES:
        raise ValidationError("Geçersiz durum filtresi.")
    if priority and priority not in PRIORITIES:
        raise ValidationError("Geçersiz öncelik filtresi.")
    return {"q": params.get("q", ""), "status": status, "priority": priority}
