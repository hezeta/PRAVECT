"""Atomic application operations and status machine."""
from database import add_event, changes, item_from_row, utc_now, write_transaction
from validation import TRANSITIONS


class MissingItem(Exception):
    pass


class InvalidTransition(Exception):
    pass


def insert_item(db_path, data):
    stamp = utc_now()
    with write_transaction(db_path) as conn:
        cursor = conn.execute("""
            INSERT INTO items (title, description, priority, status, due_date, created_at, updated_at)
            VALUES (?, ?, ?, 'todo', ?, ?, ?)
        """, (data["title"], data["description"], data["priority"], data["due_date"], stamp, stamp))
        item_id = cursor.lastrowid
        fields = {**data, "status": "todo"}
        add_event(conn, item_id, "created", stamp, changes({}, fields))
        item = item_from_row(conn.execute("SELECT * FROM items WHERE id = ?", (item_id,)).fetchone())
    return item


def update_item(db_path, item_id, data):
    with write_transaction(db_path) as conn:
        old = item_from_row(conn.execute("SELECT * FROM items WHERE id = ?", (item_id,)).fetchone())
        if old is None:
            raise MissingItem
        differences = changes(old, data)
        if differences:
            stamp = utc_now()
            fields = list(data)
            conn.execute("UPDATE items SET " + ", ".join(f"{field} = ?" for field in fields)
                         + ", updated_at = ? WHERE id = ?",
                         [*(data[field] for field in fields), stamp, item_id])
            add_event(conn, item_id, "updated", stamp, differences)
        item = item_from_row(conn.execute("SELECT * FROM items WHERE id = ?", (item_id,)).fetchone())
    return item


def transition_item(db_path, item_id, target):
    with write_transaction(db_path) as conn:
        old = item_from_row(conn.execute("SELECT * FROM items WHERE id = ?", (item_id,)).fetchone())
        if old is None:
            raise MissingItem
        if TRANSITIONS[old["status"]] != target:
            raise InvalidTransition(f"{old['status']} → {target} geçişine izin verilmiyor.")
        stamp = utc_now()
        conn.execute("UPDATE items SET status = ?, updated_at = ? WHERE id = ?", (target, stamp, item_id))
        add_event(conn, item_id, "status_changed", stamp,
                  {"status": {"before": old["status"], "after": target}})
        item = item_from_row(conn.execute("SELECT * FROM items WHERE id = ?", (item_id,)).fetchone())
    return item
