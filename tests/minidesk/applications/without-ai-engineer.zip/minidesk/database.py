"""SQLite schema, transactions, and query helpers."""
import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone, date
from pathlib import Path
import unicodedata

SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    priority TEXT NOT NULL CHECK (priority IN ('low','normal','high')),
    status TEXT NOT NULL CHECK (status IN ('todo','doing','done')),
    due_date TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id INTEGER NOT NULL REFERENCES items(id),
    type TEXT NOT NULL CHECK (type IN ('created','updated','status_changed')),
    timestamp TEXT NOT NULL,
    changes TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_items_updated ON items(updated_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS idx_events_item ON events(item_id, id);
"""


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def initialize(db_path):
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with connect(db_path) as conn:
        conn.executescript(SCHEMA)


@contextmanager
def connect(db_path):
    conn = sqlite3.connect(str(db_path), timeout=10, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 10000")
    try:
        yield conn
    finally:
        conn.close()


@contextmanager
def write_transaction(db_path):
    with connect(db_path) as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            yield conn
            conn.commit()
        except BaseException:
            conn.rollback()
            raise


def item_from_row(row):
    return dict(row) if row is not None else None


def event_from_row(row):
    result = dict(row)
    result["changes"] = json.loads(result["changes"])
    return result


def changes(before, after):
    return {key: {"before": before.get(key), "after": value}
            for key, value in after.items() if before.get(key) != value}


def add_event(conn, item_id, event_type, timestamp, differences):
    conn.execute(
        "INSERT INTO events (item_id, type, timestamp, changes) VALUES (?, ?, ?, ?)",
        (item_id, event_type, timestamp, json.dumps(differences, ensure_ascii=False)),
    )


def search_key(text):
    """Unicode case-insensitive search; also tolerates combining Turkish I marks."""
    value = unicodedata.normalize("NFKD", text.casefold().replace("ı", "i"))
    return "".join(ch for ch in value if unicodedata.category(ch) != "Mn")


def list_items(db_path, *, q="", status="", priority=""):
    conditions, values = [], []
    if status:
        conditions.append("status = ?")
        values.append(status)
    if priority:
        conditions.append("priority = ?")
        values.append(priority)
    where = " WHERE " + " AND ".join(conditions) if conditions else ""
    with connect(db_path) as conn:
        rows = conn.execute(
            "SELECT * FROM items" + where + " ORDER BY updated_at DESC, id DESC", values
        ).fetchall()
    data = [item_from_row(row) for row in rows]
    if q:
        term = search_key(q.strip())
        data = [item for item in data if term in search_key(item["title"] + " " + item["description"])]
    return data


def get_item(db_path, item_id):
    with connect(db_path) as conn:
        return item_from_row(conn.execute("SELECT * FROM items WHERE id = ?", (item_id,)).fetchone())


def get_events(db_path, item_id):
    with connect(db_path) as conn:
        return [event_from_row(row) for row in conn.execute(
            "SELECT * FROM events WHERE item_id = ? ORDER BY id DESC", (item_id,)
        )]


def summary(db_path, today=None):
    today = today or date.today()  # Local operator's calendar day, not the UTC date.
    with connect(db_path) as conn:
        row = conn.execute("""
            SELECT COUNT(*) AS total,
                COALESCE(SUM(CASE WHEN status != 'done' THEN 1 ELSE 0 END), 0) AS open,
                COALESCE(SUM(CASE WHEN status = 'done' THEN 1 ELSE 0 END), 0) AS done,
                COALESCE(SUM(CASE WHEN status != 'done' AND due_date IS NOT NULL
                                 AND due_date < ? THEN 1 ELSE 0 END), 0) AS overdue
            FROM items
        """, (today.isoformat(),)).fetchone()
    return dict(row)
