"""Static front-end contract checks; not a substitute for browser layout QA."""
import re
import unittest
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / 'static'


class FormParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.labels = set()
        self.inputs = set()
        self.buttons = set()

    def handle_starttag(self, tag, attrs):
        attributes = dict(attrs)
        if tag == 'label':
            self.labels.add(attributes.get('for'))
        if tag in ('input', 'textarea', 'select'):
            self.inputs.add(attributes.get('id'))
        if tag == 'button':
            self.buttons.add(attributes.get('type'))


class FrontendContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.html = (ROOT / 'index.html').read_text(encoding='utf-8')
        cls.css = (ROOT / 'styles.css').read_text(encoding='utf-8')
        cls.js = (ROOT / 'app.js').read_text(encoding='utf-8')

    def test_inputs_have_explicit_labels(self):
        parser = FormParser()
        parser.feed(self.html)
        self.assertTrue(parser.inputs.issubset(parser.labels))
        self.assertIn('submit', parser.buttons)
        self.assertIn('button', parser.buttons)

    def test_accessibility_skeleton(self):
        for marker in ('lang="tr"', 'href="#main"', 'aria-live="polite"', 'role="alert"',
                       'id="item-form"', 'id="item-list"', 'id="event-list"'):
            self.assertIn(marker, self.html)
        self.assertIn(':focus-visible', self.css)

    def test_user_text_not_inserted_as_html(self):
        self.assertNotIn('.innerHTML', self.js)
        self.assertIn('textContent', self.js)
        self.assertNotIn('document.write', self.js)

    def test_responsive_layout_rules(self):
        self.assertIn('@media(max-width:430px)', self.css)
        self.assertIn('@media(max-width:760px)', self.css)
        self.assertIn('minmax(0,1fr)', self.css)
        self.assertIn('overflow-wrap:anywhere', self.css)

    def test_no_remote_dependencies(self):
        self.assertNotIn('https://', self.html)
        self.assertNotIn('http://', self.html)
        self.assertFalse(re.search(r'\b(import|require)\s*\(', self.js))


if __name__ == '__main__':
    unittest.main()
