"""Real HTTP API integration tests. All databases are temporary."""
import json
import sqlite3
import tempfile
import threading
import unittest
from datetime import date, timedelta
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from app import create_server


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="minidesk-test-")
        self.addCleanup(self.temp.cleanup)
        self.db_path = Path(self.temp.name) / "test.sqlite3"
        self.start_server()

    def start_server(self):
        self.server = create_server(self.db_path, port=0)
        self.assertEqual(self.server.server_address[0], "127.0.0.1")
        self.url = f"http://127.0.0.1:{self.server.server_port}"
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def stop_server(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=5)

    def tearDown(self):
        self.stop_server()

    def request(self, method, path, data=None, *, raw=False, content_type="application/json"):
        body = None if data is None else (data if raw else json.dumps(data, ensure_ascii=False).encode("utf-8"))
        req = Request(self.url + path, data=body, method=method)
        if body is not None:
            req.add_header("Content-Type", content_type)
        try:
            response = urlopen(req, timeout=3)
        except HTTPError as exc:
            response = exc
        with response:
            content = response.read()
            return response.status, (json.loads(content) if content and response.headers.get_content_type() == "application/json" else content), dict(response.headers), content

    def post(self, title="Birinci talep", **kwargs):
        return self.request("POST", "/api/items", {"title": title, **kwargs})

    def assert_error(self, status, payload, expected):
        self.assertEqual(status, expected)
        self.assertEqual(set(payload), {"error"})
        self.assertTrue(payload["error"]["code"])
        self.assertTrue(payload["error"]["message"])

    def test_health_and_empty_database(self):
        self.assertEqual(self.request("GET", "/api/health")[1], {"status": "ok"})
        self.assertEqual(self.request("GET", "/api/items")[1], {"items": [], "count": 0})
        self.assertEqual(self.request("GET", "/api/summary")[1], {"total": 0, "open": 0, "done": 0, "overdue": 0})

    def test_create_defaults_and_fields(self):
        status, item, headers, _ = self.post("  Ağ yazıcısı kurulumu  ")
        self.assertEqual(status, 201)
        self.assertEqual(headers["Location"], f"/api/items/{item['id']}")
        self.assertEqual(item["title"], "Ağ yazıcısı kurulumu")
        self.assertEqual(item["description"], "")
        self.assertEqual(item["priority"], "normal")
        self.assertEqual(item["status"], "todo")
        self.assertIsNone(item["due_date"])
        self.assertTrue(item["created_at"].endswith("Z"))
        self.assertEqual(item["created_at"], item["updated_at"])
        self.assertIsInstance(item["id"], int)
        self.assertEqual(self.request("GET", f"/api/items/{item['id']}")[1], item)

    def test_create_with_all_optional_fields(self):
        status, item, _, _ = self.post("Yazıcı kontrolü", description="Kağıt besleme testi", priority="high", due_date="2030-03-01")
        self.assertEqual(status, 201)
        self.assertEqual(item["priority"], "high")
        self.assertEqual(item["description"], "Kağıt besleme testi")
        self.assertEqual(item["due_date"], "2030-03-01")

    def test_create_invalid_titles(self):
        for title in ("", "  ", "x", "a" * 101, 32, None):
            with self.subTest(title=title):
                status, body, _, _ = self.post(title)
                self.assert_error(status, body, 422)
        self.assertEqual(self.request("GET", "/api/items")[1]["count"], 0)

    def test_create_bad_optional_values(self):
        for obj in ({"description": "x" * 1001}, {"priority": "urgent"}, {"priority": 5},
                    {"due_date": "2026-02-30"}, {"due_date": "01/02/2026"}, {"description": None}):
            with self.subTest(obj=obj):
                self.assertEqual(self.post("Kontrol işi", **obj)[0], 422)
        self.assertEqual(self.request("GET", "/api/items")[1]["count"], 0)

    def test_forbidden_create_fields(self):
        for obj in ({"status": "done"}, {"id": 99}, {"created_at": "yesterday"}):
            with self.subTest(obj=obj):
                self.assertEqual(self.post("Kontrol işi", **obj)[0], 422)

    def test_malformed_json_http_400(self):
        for body in (b"{not json", b"", b"\xff", b"["):
            with self.subTest(body=body):
                status, response, _, _ = self.request("POST", "/api/items", body, raw=True)
                self.assert_error(status, response, 400)

    def test_non_object_json_and_wrong_media_type(self):
        self.assertEqual(self.request("POST", "/api/items", [1, 2])[0], 422)
        self.assertEqual(self.request("POST", "/api/items", b'{}', raw=True, content_type="text/plain")[0], 415)

    def test_update_only_allowed_fields(self):
        item = self.post()[1]
        status, changed, _, _ = self.request("PATCH", f"/api/items/{item['id']}", {
            "title": "Yeni başlık", "description": "Yeni açıklama", "priority": "low", "due_date": "2028-06-04"})
        self.assertEqual(status, 200)
        self.assertEqual(changed["id"], item["id"])
        self.assertEqual(changed["created_at"], item["created_at"])
        self.assertEqual(changed["status"], "todo")
        self.assertEqual(changed["title"], "Yeni başlık")
        self.assertEqual(changed["description"], "Yeni açıklama")
        self.assertEqual(changed["priority"], "low")
        self.assertEqual(changed["due_date"], "2028-06-04")
        self.assertEqual(len(self.request("GET", f"/api/items/{item['id']}/events")[1]["events"]), 2)

    def test_update_rejected_request_preserves_record_and_events(self):
        item = self.post()[1]
        for bad in ({"title": "x"}, {"status": "done"}, {"id": 77}, {}, {"due_date": "2025-13-01"}, {"description": 4}):
            with self.subTest(bad=bad):
                status, payload, _, _ = self.request("PATCH", f"/api/items/{item['id']}", bad)
                self.assert_error(status, payload, 422)
        self.assertEqual(self.request("GET", f"/api/items/{item['id']}")[1], item)
        self.assertEqual(len(self.request("GET", f"/api/items/{item['id']}/events")[1]["events"]), 1)

    def test_update_same_value_is_noop(self):
        item = self.post()[1]
        result = self.request("PATCH", f"/api/items/{item['id']}", {"title": item["title"]})[1]
        self.assertEqual(result, item)
        self.assertEqual(len(self.request("GET", f"/api/items/{item['id']}/events")[1]["events"]), 1)

    def test_workflow_todo_doing_done_doing(self):
        item = self.post()[1]
        for target in ("doing", "done", "doing"):
            status, updated, _, _ = self.request("POST", f"/api/items/{item['id']}/transition", {"status": target})
            self.assertEqual(status, 200)
            self.assertEqual(updated["status"], target)
        events = self.request("GET", f"/api/items/{item['id']}/events")[1]["events"]
        self.assertEqual([event["type"] for event in events], ["status_changed"] * 3 + ["created"])
        self.assertEqual(events[0]["changes"]["status"], {"before": "done", "after": "doing"})

    def test_forbidden_transition_409_no_mutation(self):
        item = self.post()[1]
        for target in ("done", "todo"):
            status, response, _, _ = self.request("POST", f"/api/items/{item['id']}/transition", {"status": target})
            self.assert_error(status, response, 409)
        self.assertEqual(self.request("GET", f"/api/items/{item['id']}")[1], item)
        self.assertEqual(len(self.request("GET", f"/api/items/{item['id']}/events")[1]["events"]), 1)

    def test_transition_payload_validation(self):
        item = self.post()[1]
        for bad in ([], {}, {"status": "closed"}, {"status": "doing", "title": "x"}, {"status": None}):
            with self.subTest(bad=bad):
                self.assertEqual(self.request("POST", f"/api/items/{item['id']}/transition", bad)[0], 422)
        self.assertEqual(len(self.request("GET", f"/api/items/{item['id']}/events")[1]["events"]), 1)

    def test_event_details_and_read_only(self):
        item = self.post("Deneme", description="İlk not")[1]
        self.request("PATCH", f"/api/items/{item['id']}", {"description": "İkinci not"})
        ev = self.request("GET", f"/api/items/{item['id']}/events")[1]["events"]
        self.assertEqual(ev[0]["type"], "updated")
        self.assertEqual(ev[0]["item_id"], item["id"])
        self.assertTrue(ev[0]["timestamp"].endswith("Z"))
        self.assertEqual(ev[0]["changes"], {"description": {"before": "İlk not", "after": "İkinci not"}})
        self.assertEqual(ev[1]["type"], "created")
        self.assertEqual(ev[1]["changes"]["title"], {"before": None, "after": "Deneme"})
        self.assertEqual(self.request("POST", f"/api/items/{item['id']}/events", {})[0], 405)

    def test_missing_id_404(self):
        for method, url, data in (("GET", "/api/items/9999", None), ("PATCH", "/api/items/9999", {"title": "Bilinmeyen"}),
                                  ("POST", "/api/items/9999/transition", {"status": "doing"}),
                                  ("GET", "/api/items/9999/events", None)):
            with self.subTest(method=method, url=url):
                status, response, _, _ = self.request(method, url, data)
                self.assert_error(status, response, 404)

    def test_search_in_both_fields_casefold_turkish(self):
        self.post("İSTANBUL donanım")
        self.post("Ağ bakımı", description="Klavye bağlantısı çalışmıyor")
        self.post("Yedekleme")
        self.assertEqual(self.request("GET", "/api/items?q=istanbul")[1]["count"], 1)
        self.assertEqual(self.request("GET", "/api/items?q=KLAVYE")[1]["count"], 1)
        self.assertEqual(self.request("GET", "/api/items?q=bulunamayan")[1]["count"], 0)

    def test_combined_status_priority_search_filters(self):
        first = self.post("Kritik sunucu", priority="high")[1]
        second = self.post("Kritik tarayıcı", priority="high")[1]
        self.post("Kritik yazıcı", priority="low")
        self.request("POST", f"/api/items/{first['id']}/transition", {"status": "doing"})
        self.request("POST", f"/api/items/{second['id']}/transition", {"status": "doing"})
        response = self.request("GET", "/api/items?q=SUNUCU&priority=high&status=doing")[1]
        self.assertEqual([r["id"] for r in response["items"]], [first["id"]])
        self.assertEqual(self.request("GET", "/api/items?status=done")[1]["count"], 0)

    def test_invalid_filters(self):
        for query in ("?status=bad", "?priority=critical"):
            self.assertEqual(self.request("GET", "/api/items" + query)[0], 422)

    def test_recently_updated_first(self):
        first = self.post("İlk talep")[1]
        second = self.post("İkinci talep")[1]
        self.request("PATCH", f"/api/items/{first['id']}", {"title": "İlk talep düzeltildi"})
        items = self.request("GET", "/api/items")[1]["items"]
        self.assertEqual([i["id"] for i in items], [first["id"], second["id"]])

    def test_overdue_open_and_done_logic(self):
        yesterday = (date.today() - timedelta(days=1)).isoformat()
        tomorrow = (date.today() + timedelta(days=1)).isoformat()
        first = self.post("Gecikmiş açık", due_date=yesterday)[1]
        done = self.post("Gecikmiş tamam", due_date=yesterday)[1]
        self.post("Son tarih yarın", due_date=tomorrow)
        self.post("Tarihsiz talep")
        self.request("POST", f"/api/items/{done['id']}/transition", {"status": "doing"})
        self.request("POST", f"/api/items/{done['id']}/transition", {"status": "done"})
        self.assertEqual(self.request("GET", "/api/summary")[1], {"total": 4, "open": 3, "done": 1, "overdue": 1})
        self.request("POST", f"/api/items/{first['id']}/transition", {"status": "doing"})
        self.assertEqual(self.request("GET", "/api/summary")[1]["overdue"], 1)
        self.request("POST", f"/api/items/{first['id']}/transition", {"status": "done"})
        self.assertEqual(self.request("GET", "/api/summary")[1]["overdue"], 0)

    def test_utf8_export_no_events(self):
        self.post("Türkçe iş", description="İç ağ bağlantısı")
        status, data, headers, raw = self.request("GET", "/api/export")
        self.assertEqual(status, 200)
        self.assertEqual(headers["Content-Disposition"], 'attachment; filename="minidesk-items.json"')
        self.assertIsInstance(data, list)
        self.assertEqual(data[0]["title"], "Türkçe iş")
        self.assertIn("İç ağ".encode("utf-8"), raw)
        self.assertNotIn("events", data[0])

    def test_restart_keeps_records_and_events(self):
        item = self.post()[1]
        self.request("POST", f"/api/items/{item['id']}/transition", {"status": "doing"})
        self.stop_server()
        self.start_server()
        self.assertEqual(self.request("GET", f"/api/items/{item['id']}")[1]["status"], "doing")
        self.assertEqual(len(self.request("GET", f"/api/items/{item['id']}/events")[1]["events"]), 2)

    def test_atomic_create_rollback_when_event_fails(self):
        with sqlite3.connect(self.db_path) as db:
            db.execute("CREATE TRIGGER fail_create BEFORE INSERT ON events WHEN NEW.type='created' BEGIN SELECT RAISE(ABORT, 'test fault'); END")
        status, response, _, _ = self.post("Geri al")
        self.assert_error(status, response, 500)
        self.assertEqual(self.request("GET", "/api/items")[1]["count"], 0)

    def test_atomic_transition_rollback_when_event_fails(self):
        item = self.post()[1]
        with sqlite3.connect(self.db_path) as db:
            db.execute("CREATE TRIGGER fail_transition BEFORE INSERT ON events WHEN NEW.type='status_changed' BEGIN SELECT RAISE(ABORT, 'test fault'); END")
        status, response, _, _ = self.request("POST", f"/api/items/{item['id']}/transition", {"status": "doing"})
        self.assert_error(status, response, 500)
        self.assertEqual(self.request("GET", f"/api/items/{item['id']}")[1], item)
        self.assertEqual(len(self.request("GET", f"/api/items/{item['id']}/events")[1]["events"]), 1)

    def test_atomic_update_rollback_when_event_fails(self):
        item = self.post()[1]
        with sqlite3.connect(self.db_path) as db:
            db.execute("CREATE TRIGGER fail_update BEFORE INSERT ON events WHEN NEW.type='updated' BEGIN SELECT RAISE(ABORT, 'test fault'); END")
        status, response, _, _ = self.request("PATCH", f"/api/items/{item['id']}", {"priority": "high"})
        self.assert_error(status, response, 500)
        self.assertEqual(self.request("GET", f"/api/items/{item['id']}")[1], item)
        self.assertEqual(len(self.request("GET", f"/api/items/{item['id']}/events")[1]["events"]), 1)

    def test_http_methods_missing_routes_and_security_headers(self):
        self.assert_error(*self.request("GET", "/api/nonexistent")[:2], 404)
        self.assertEqual(self.request("DELETE", "/api/items")[0], 405)
        self.assertEqual(self.request("GET", "/../app.py")[0], 404)
        status, _, headers, raw = self.request("GET", "/")  # page is HTML, not JSON
        self.assertEqual(status, 200)
        self.assertEqual(headers["X-Content-Type-Options"], "nosniff")
        self.assertEqual(headers["X-Frame-Options"], "DENY")
        self.assertIn(b'<html lang="tr">', raw)


if __name__ == "__main__":
    unittest.main()
