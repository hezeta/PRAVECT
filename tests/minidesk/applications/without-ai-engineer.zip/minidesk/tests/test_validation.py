import unittest
from datetime import date
from pathlib import Path
import tempfile

from database import initialize, search_key, summary
from validation import ValidationError, validate_fields, validate_filters, validate_transition


class ValidationTests(unittest.TestCase):
    def test_boundary_lengths(self):
        for length in (3, 100):
            self.assertEqual(len(validate_fields({"title": "a" * length}, creating=True)["title"]), length)
        self.assertEqual(len(validate_fields({"title": "abc", "description": "x" * 1000}, creating=True)["description"]), 1000)
        for length in (2, 101):
            with self.assertRaises(ValidationError):
                validate_fields({"title": "a" * length}, creating=True)

    def test_date_validation_and_nullable_dates(self):
        self.assertEqual(validate_fields({"due_date": ""})["due_date"], None)
        self.assertEqual(validate_fields({"due_date": None})["due_date"], None)
        self.assertEqual(validate_fields({"due_date": "2024-02-29"})["due_date"], "2024-02-29")
        for value in ("2025-02-29", "2020-04-31", "2025-1-01", "2025-01-1", "random", 2025):
            with self.subTest(value=value), self.assertRaises(ValidationError):
                validate_fields({"due_date": value})

    def test_mutations_cannot_set_status(self):
        for payload in ({"status": "done"}, {"updated_at": "2020-01-01"}, {"id": 2}):
            with self.assertRaises(ValidationError):
                validate_fields(payload)
        self.assertEqual(validate_transition({"status": "doing"}), "doing")
        with self.assertRaises(ValidationError):
            validate_transition({"status": "invalid"})

    def test_case_insensitivity(self):
        self.assertEqual(search_key("İSTANBUL"), search_key("istanbul"))
        self.assertEqual(search_key("BAKIM"), search_key("bakım"))

    def test_filter_validation(self):
        self.assertEqual(validate_filters({"status": "todo", "priority": "high", "q": "deneme"}),
                         {"status": "todo", "priority": "high", "q": "deneme"})
        with self.assertRaises(ValidationError):
            validate_filters({"status": "blocked"})

    def test_fresh_empty_database_summary(self):
        with tempfile.TemporaryDirectory() as folder:
            db = Path(folder) / "nested" / "tasks.sqlite3"
            initialize(db)
            self.assertTrue(db.exists())
            self.assertEqual(summary(db, today=date(2026, 10, 13)),
                             {"total": 0, "open": 0, "done": 0, "overdue": 0})


if __name__ == "__main__":
    unittest.main()
